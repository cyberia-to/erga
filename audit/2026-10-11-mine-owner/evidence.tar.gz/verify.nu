def demand [ok: bool, message: string] {
    if not $ok { error make {msg: $message} }
}

def sha [file: path] { open --raw $file | hash sha256 }

def fmt-sections [file: path] {
    open --raw $file
    | str replace --all --regex '/(private/)?tmp/erga-mine-owner-execution/(source|parent)/erga/' 'ERGA/'
    | split row --regex '(?m)(?=^Diff in )'
    | where {|s| not ($s | is-empty)}
}

def app-outcomes [file: path] {
    open --raw $file | lines
    | where {|s| $s =~ '^test (chime::|store::)'} | sort
}

def main [capsule: path] {
    let root = ($capsule | path expand)
    let manifest = (open ($root | path join inventory.json))
    for row in $manifest {
        let file = ($root | path join $row.path)
        demand ((sha $file) == $row.sha256) $"payload hash differs: ($row.path)"
        demand ((open --raw $file | into binary | bytes length) == $row.bytes) $"payload length differs: ($row.path)"
    }

    let current_path = ($root | path join execution current-source.json)
    let current_hash = (sha $current_path)
    let current = (open $current_path)
    let parent = (open ($root | path join execution parent-source.json))
    demand ($parent.revision == $current.base) 'parent revision differs'
    demand ($parent.files == (open ($root | path join plan erga-source.json))) 'parent file manifest differs'
    let snapshot_records = ($manifest | where {|r| $r.path =~ '^execution/snapshots/[^/]+/source.json$'})
    for row in $snapshot_records {
        let path = ($root | path join $row.path)
        let id = ($row.path | path dirname | path basename)
        demand ((sha $path) == $id) 'snapshot directory identity differs'
        let source = (open $path)
        for file in $source.files {
            demand ((sha ($path | path dirname | path join $file.path)) == $file.sha256) $"snapshot body differs: ($file.path)"
        }
    }
    let final = ($root | path join execution snapshots $current_hash)
    demand ((sha ($final | path join source.json)) == $current_hash) 'final snapshot missing'
    demand ((sha ($final | path join specs README.md)) == (sha ($root | path join plan proposed README.md))) 'spec differs from approved proposal'
    let before = (open ($root | path join source parent-before.json))
    demand ($before.revision == $current.base) 'before revision differs'
    for row in ($before.files | where existed) {
        demand ((sha ($root | path join $row.retained)) == $row.sha256) 'parent before-body differs'
        demand (($parent.files | where path == $row.path | get 0.sha256) == $row.sha256) 'before body differs from full parent manifest'
    }
    let old_spec = (open --raw ($root | path join source parent-before specs README.md))
    let new_spec = (open --raw ($final | path join specs README.md))
    let clause = 'CPU and GPU access must address the same physical pages.'
    demand (($old_spec | str contains $clause) and ($new_spec | str contains $clause)) 'physical-pages clause changed'

    let made = (^mktemp -d /tmp/erga-mine-patch.XXXXXX | complete)
    demand ($made.exit_code == 0) 'mktemp failed'
    let scratch = ($made.stdout | str trim)
    try {
        for row in ($before.files | where existed) {
            let destination = ($scratch | path join $row.path)
            mkdir ($destination | path dirname)
            cp ($root | path join $row.retained) $destination
        }
        let applied = (^git -C $scratch apply --no-index ($root | path join source candidate.diff) | complete)
        demand ($applied.exit_code == 0) $"patch failed: ($applied.stderr)"
        for row in $current.files {
            demand ((sha ($scratch | path join $row.path)) == $row.sha256) $"patch result differs: ($row.path)"
        }
    } catch {|failure|
        rm -r $scratch
        error make {msg: $failure.msg}
    }
    rm -r $scratch

    let gates = (open ($root | path join execution gates.json))
    let mapping = (open ($root | path join execution command-source-map.json))
    for gate in $gates {
        let label = $gate.label
        let record = (open ($root | path join execution logs $"($label).json"))
        for stream in [stdout stderr] {
            demand ((sha ($root | path join execution logs $"($label).($stream)")) == ($record | get $"($stream)_sha256")) $"raw stream differs: ($label).($stream)"
        }
        demand (($record | select label command args exit_code stdout_sha256 stderr_sha256) == ($gate | reject source)) 'gate index differs'
        let source = ($mapping | where label == $label | get 0)
        demand ($source == $gate.source) 'source map differs'
        if $source.source_manifest != null {
            demand ((sha ($root | path join $source.source_manifest)) == $source.source_sha256) 'executed source identity differs'
        } else {
            demand ($label == '01-check') 'unexplained missing source snapshot'
        }
        if ($record.cwd | str ends-with '/parent/erga') {
            demand ($source.source_manifest == 'execution/parent-source.json') 'parent incorrectly mapped to candidate'
        }
    }
    for version in [v1 v2] {
        let compact = (open ($root | path join reviews $"code-($version)" command-records.json))
        for row in $compact.records {
            mut expanded = ($row | reject environment_id | insert environment ($compact.environments | get $row.environment_id))
            for name in ($compact.dictionaries? | default {} | columns) {
                let field = $"($name)_id"
                let id = ($row | get $field)
                $expanded = ($expanded | reject $field | insert $name ($compact.dictionaries | get $name | get $id))
            }
            demand ($expanded == (open ($root | path join execution logs $"($row.label).json"))) 'compacted command loses information'
        }
    }

    let packs = (open ($root | path join reviews pack-sections.json))
    for pack in $packs {
        let body = (open --raw ($root | path join $pack.brief) | into binary)
        let index = (open ($root | path join $pack.index))
        let freeze = (open ($root | path join $pack.freeze))
        demand (($body | hash sha256) == $pack.sha256 and $pack.sha256 == $freeze.brief_sha256) 'review brief differs'
        let index_hash = if $pack.name == plan { $freeze.inventory_sha256 } else { $freeze.index_sha256 }
        demand ((sha ($root | path join $pack.index)) == $index_hash) 'review index differs'
        demand (($pack.sections | length) == ($index | length)) 'review section count differs'
        for section in $pack.sections {
            let entry = ($index | get ($section.number - 1))
            demand ($section.name == $entry.name and $section.length == $entry.packed_bytes and $section.sha256 == $entry.packed_sha256) 'section index differs'
            let last = $section.offset + $section.length
            let content = ($body | bytes at $section.offset..<$last)
            demand (($content | hash sha256) == $section.sha256) 'packed section differs'
            if $section.encoding == byte-exact {
                demand ($entry.sha256 == $section.sha256 and $entry.bytes == $section.length) 'byte-exact section loses information'
            }
        }
    }
    let submitted = (open ($root | path join reviews code-v2 review-inputs.json))
    for file in $current.files {
        let entry = ($submitted | where name == $"candidate/($file.path)" | get 0)
        demand ($entry.sha256 == $file.sha256) 'submitted CODE source differs'
    }

    let oracle_path = ($root | path join oracle)
    let oracle_receipt = (open ($oracle_path | path join execution.json))
    for row in [[source main.go] [manifest go.mod] [lock go.sum] [stdout vectors.json] [stderr stderr.txt]] {
        demand ((sha ($oracle_path | path join $row.1)) == ($oracle_receipt | get $"($row.0)_sha256")) 'independent oracle receipt differs'
    }
    # Preserve u64 decimal lexemes before JSON parsing; Nu's numeric representation
    # would round the wrapping nonce 18446744073709551614 through floating point.
    let oracle = (open --raw ($oracle_path | path join vectors.json)
        | str replace --all --regex '"(nonce_base|nonce)": ([0-9]+)' '"$1": "$2"' | from json)
    let batches = ($oracle.vectors | each {|r| $"($r.rows) ($r.kind) ($r.nonce_base) ($r.count) ($r.xor)"} | str join (char nl)) + (char nl)
    let individual = ($oracle.individual | each {|r| $"($r.rows) ($r.kind) ($r.nonce) ($r.digest)"} | str join (char nl)) + (char nl)
    demand ($batches == (open --raw ($final | path join rs mine-bench tests fixtures batches.txt))) 'full batch literals differ'
    demand ($individual == (open --raw ($final | path join rs mine-bench tests fixtures individual.txt))) 'individual digest literals differ'
    demand ($oracle.published_row == '77065d25b622a8251094d869edf6b4e9ba0708a8db1f239cb68e4eeb45851621') 'published KAT differs'
    demand (($oracle.texture_indices_nonce0_rows16384 | any {|i| $i >= 8192 and $i < 16384})) 'texture second-row witness absent'
    demand (($oracle.vectors | where count == 0 | all {|v| $v.xor == ('0' | fill --width 64 --character 0)})) 'empty XOR differs'

    let candidate_fmt = (fmt-sections ($root | path join execution logs 18-workspace-fmt.stdout))
    let parent_fmt = (fmt-sections ($root | path join execution logs 25-parent-fmt.stdout))
    let unchanged = {|sections|
        $sections | where {|section| not ($current.files | any {|file| $section | str starts-with $"Diff in ERGA/($file.path):"})}
    }
    demand ((do $unchanged $candidate_fmt) == (do $unchanged $parent_fmt)) 'unrelated formatter diagnostics changed'
    demand ((app-outcomes ($root | path join execution logs 15-workspace-tests.stdout)) == (app-outcomes ($root | path join execution logs 32-parent-app-test.stdout))) 'parent app outcomes differ'
    for label in [15-workspace-tests 32-parent-app-test] {
        let output = (open --raw ($root | path join execution logs $"($label).stdout"))
        demand (($output | split row "panicked at rs/app/src/chime.rs:132:39:\nattempt to multiply with overflow" | length) == 3) 'exact app overflow pair differs'
    }
    {
        payloads: ($manifest | length), source_base: $current.base,
        source_sha256: $current_hash, candidate_files: ($current.files | length),
        complete_overlay_snapshots: ($snapshot_records | length),
        parent_manifest_files: ($parent.files | length),
        records: ($gates | length), raw_streams: (($gates | length) * 2),
        complete_review_packs: ($packs | length), review_sections: ($packs | each {|p| $p.sections | length}),
        oracle_batches: ($oracle.vectors | length), oracle_individual: ($oracle.individual | length),
        candidate_fmt_sections: ($candidate_fmt | length), parent_fmt_sections: ($parent_fmt | length),
        unchanged_fmt_sections: (do $unchanged $candidate_fmt | length),
        exact_app_overflow_failures: 2, patch_reconstructs_candidate: true,
        initial_exploratory_body_missing: ['01-check'],
        reran_native_work: false, refetched_omitted_primaries: false,
        scope: 'Portable evidence integrity and relationship replay; original native/upstream checks remain recorded observations.'
    } | to json | print
}
