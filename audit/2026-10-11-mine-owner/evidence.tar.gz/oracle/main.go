// Independent scalar benchmark oracle. No Erga/Kadek/native code is imported.
package main

import (
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"golang.org/x/crypto/blake2b"
	"math/big"
	"os"
)

var message = [32]byte{0xa5, 0xa5, 0xa5, 0xa5, 0xde, 0xad, 0xbe, 0xef, 0xca, 0xfe, 0xba, 0xbe, 0x12, 0x34, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0xf0, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc}

func row(index, height uint32) [32]byte {
	var in [8]byte
	binary.LittleEndian.PutUint32(in[:4], index)
	binary.LittleEndian.PutUint32(in[4:], height)
	return blake2b.Sum256(in[:])
}
func littleInteger(b []byte) *big.Int {
	r := make([]byte, len(b))
	for i, v := range b {
		r[len(b)-1-i] = v
	}
	return new(big.Int).SetBytes(r)
}
func little256(n *big.Int) [32]byte {
	var out [32]byte
	b := n.Bytes()
	for i := 0; i < len(b) && i < 32; i++ {
		out[i] = b[len(b)-1-i]
	}
	return out
}
func digest(nonce, rows uint64, height uint32, kind string) [32]byte {
	var input [40]byte
	copy(input[:32], message[:])
	binary.LittleEndian.PutUint64(input[32:], nonce)
	seed := blake2b.Sum256(input[:])
	if kind == "v6" {
		x := nonce + uint64(0x9e3779b97f4a7c15)
		x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9
		x = (x ^ (x >> 27)) * 0x94d049bb133111eb
		x ^= x >> 31
		binary.LittleEndian.PutUint64(seed[0:8], x)
		x *= 0x9e3779b97f4a7c15
		binary.LittleEndian.PutUint64(seed[8:16], x)
		x *= 0xbf58476d1ce4e5b9
		binary.LittleEndian.PutUint64(seed[16:24], x)
		x *= 0x94d049bb133111eb
		binary.LittleEndian.PutUint64(seed[24:32], x)
	}
	sum := new(big.Int)
	if kind == "v7" {
		r := row(0, height)
		var v [4]uint64
		for i := range v {
			v[i] = binary.LittleEndian.Uint64(seed[i*8:]) ^ binary.LittleEndian.Uint64(r[i*8:])
		}
		for i := uint64(0); i < 32; i++ {
			var b [32]byte
			binary.LittleEndian.PutUint64(b[0:8], v[0]+i)
			binary.LittleEndian.PutUint64(b[8:16], v[1]^i)
			binary.LittleEndian.PutUint64(b[16:24], v[2]+i*0x9e3779b97f4a7c15)
			binary.LittleEndian.PutUint64(b[24:32], v[3]^(i*0xbf58476d1ce4e5b9))
			sum.Add(sum, littleInteger(b[:]))
		}
	} else {
		var ext [35]byte
		copy(ext[:32], seed[:])
		copy(ext[32:], seed[:3])
		for i := 0; i < 32; i++ {
			idx := uint64(binary.BigEndian.Uint32(ext[i:i+4])) % rows
			r := row(uint32(idx), height)
			sum.Add(sum, littleInteger(r[:]))
		}
	}
	bytes := little256(sum)
	if kind == "v6" {
		return bytes
	}
	return blake2b.Sum256(bytes[:])
}
func main() {
	published := row(0x03020100, 0x07060504)
	if hex.EncodeToString(published[:]) != "77065d25b622a8251094d869edf6b4e9ba0708a8db1f239cb68e4eeb45851621" {
		panic("published BoringSSL eight-byte KAT")
	}
	var input [40]byte
	copy(input[:32], message[:])
	seed := blake2b.Sum256(input[:])
	var ext [35]byte
	copy(ext[:32], seed[:])
	copy(ext[32:], seed[:3])
	indices := []uint32{}
	for i := 0; i < 32; i++ {
		indices = append(indices, binary.BigEndian.Uint32(ext[i:i+4])%16384)
	}
	vectors := []map[string]any{}
	for _, rows := range []uint64{1, 3, 65, 8192, 16384} {
		for _, kind := range []string{"reference", "v6", "v7", "v8-distinct"} {
			for _, base := range []uint64{0, 0xfffffffffffffffe} {
				for _, count := range []uint32{0, 1, 2, 3, 4, 5, 63, 64, 65} {
					var acc [32]byte
					for i := uint32(0); i < count; i++ {
						height := uint32(0)
						if kind == "v8-distinct" && i%2 == 1 {
							height = 0x07060504
						}
						d := digest(base+uint64(i), rows, height, kind)
						for j, b := range d {
							acc[j] ^= b
						}
					}
					vectors = append(vectors, map[string]any{"rows": rows, "kind": kind, "nonce_base": base, "count": count, "xor": hex.EncodeToString(acc[:])})
				}
			}
		}
	}
	individual := []map[string]any{}
	for _, nonce := range []uint64{0, 1, 2, 63, 64, 0xffffffffffffffff} {
		for _, kind := range []string{"reference", "v6", "v7"} {
			d := digest(nonce, 65, 0, kind)
			individual = append(individual, map[string]any{"rows": 65, "height": 0, "nonce": nonce, "kind": kind, "digest": hex.EncodeToString(d[:])})
		}
	}
	out := map[string]any{"published_row": hex.EncodeToString(published[:]), "texture_indices_nonce0_rows16384": indices, "message": hex.EncodeToString(message[:]), "vectors": vectors, "individual": individual, "method": "Go x/crypto BLAKE2b; independent scalar indexing; math/big sum modulo 2^256; unsigned nonce wraps; simplified benchmark only"}
	enc := json.NewEncoder(os.Stdout)
	enc.SetIndent("", "  ")
	if err := enc.Encode(out); err != nil {
		panic(err)
	}
}
