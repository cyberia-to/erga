def main [] {
    let root = '/tmp/erga-mine-owner-plan-v1'
    let repos = (open /tmp/unimem-dependent-candidate.DU0t4L/scenarios.json | get inputs | flatten | get repo | append ['soft3', 'cyb', 'cyber', 'kadek'] | uniq | sort)
    let rows = ($repos | par-each --threads 4 {|name|
        let repo = ('/Users/master/cyber' | path join $name)
        let remote = (git -C $repo ls-remote origin HEAD | complete)
        if $remote.exit_code != 0 { {repo: $name, remote: $remote, scan: null} } else {
            let revision = ($remote.stdout | split row "\t" | first)
            let available = (git -C $repo cat-file -e $"($revision)^{commit}" | complete)
            if $available.exit_code != 0 { {repo: $name, revision: $revision, scan: null, limitation: 'remote commit unavailable in local object database; no working tree fallback'} } else {
                let scan = (git -C $repo grep -n -E 'mine[-_]bench|(^|[^[:alnum:]_])(GpuMiner|GpuMinerV9|MineVariant|mine_one|cpu_accumulate|cpu_mine_for|gpu_mine_for)([^[:alnum:]_]|$)' $revision -- '*.toml' '*.lock' '*.rs' '*.nu' AGENTS.md CLAUDE.md | complete)
                {repo: $name, revision: $revision, scan: $scan}
            }
        }
    } | sort-by repo)
    {observed: (date now | format date '%+'), commands: ['git ls-remote origin HEAD', 'git cat-file -e <rev>^{commit}', "git grep -n -E mine[-_]bench|(^|[^[:alnum:]_])(GpuMiner|GpuMinerV9|MineVariant|mine_one|cpu_accumulate|cpu_mine_for|gpu_mine_for)([^[:alnum:]_]|$) <rev> -- *.toml *.lock *.rs *.nu AGENTS.md CLAUDE.md"], corpus: 'repositories named by previous Honeycrisp dependent archive closure, plus soft3/cyb/cyber/kadek; not whole organization', results: $rows, limits: 'source scan only; no dependent compile, rung, kelvin or release claim'} | to json | save --force ($root | path join external-inventory.json)
    $rows | each {|row| {repo: $row.repo, revision: $row.revision?, scan_exit: $row.scan.exit_code?, lines: ($row.scan.stdout? | default '' | lines | length)} } | print
    let soft = ($rows | where repo == 'soft3' | first)
    if $soft.revision? != null {
        let result = (git -C /Users/master/cyber/soft3 show $"($soft.revision):release/components.toml" | complete)
        if $result.exit_code == 0 {
            $result.stdout | save --force ($root | path join components.toml)
            {revision: $soft.revision, sha256: ($result.stdout | hash sha256), erga_matches: ($result.stdout | lines | where { $in =~ '(?i)erga|blake.bench|rtable.bench' })} | to json | save --force ($root | path join component-scope.json)
        }
    }
}
