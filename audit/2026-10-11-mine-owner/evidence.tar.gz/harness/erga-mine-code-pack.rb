require 'json';require 'digest';require 'fileutils';require 'open3';require 'time'
w='/Users/master/cyber/erga-unimem-mine-owner';r='/tmp/erga-mine-owner-execution';p='/tmp/erga-mine-owner-plan-v1';out='/tmp/erga-mine-owner-code-v2';FileUtils.mkdir_p(out)
rows=[];parts=[]
add=lambda do |name,path,git=nil|
 raw=File.binread(path);packed=path.end_with?('.json') ? (JSON.generate(JSON.parse(raw))+"\n").b : raw
 if git
  repo,rev,relative=git;bytes,status=Open3.capture2('git','-C',repo,'show',rev+':'+relative);raise 'git body differs' unless status.success? && bytes.b==raw
 end
 row={name:name,path:path,bytes:raw.bytesize,sha256:Digest::SHA256.hexdigest(raw),encoding:path.end_with?('.json') ? 'lossless compact JSON' : 'byte-exact',packed_bytes:packed.bytesize,packed_sha256:Digest::SHA256.hexdigest(packed)};row[:git]={repo:git[0],revision:git[1],path:git[2]} if git
 rows<<row;parts<<packed
end
%w[plan.md execution.md].each{|f|add.call('task/'+f,w+'/.claude/tasks/mine-owner/'+f)}
add.call('review/plan-verdict','/tmp/erga-mine-owner-plan-v1-grok-review.txt')
source=JSON.parse(File.read(r+'/current-source.json'));source.fetch('files').each{|f|add.call('candidate/'+f.fetch('path'),r+'/source/erga/'+f.fetch('path'))}
old=JSON.parse(File.read(p+'/review-inputs.json'));by_name=old.to_h{|a|[a.fetch('name'),a]}
old_names=%w[erga/CLAUDE.md erga/Cargo.toml erga/rs/mine-bench/Cargo.toml erga/rs/rtable-bench/Cargo.toml erga/rs/blake-bench/Cargo.toml erga/rs/mine-bench/src/lib.rs erga/rs/mine-bench/src/main.rs erga/rs/mine-bench/src/texture_ffi.rs erga/rs/rtable-bench/src/table.rs erga/specs/README.md erga/rs/rtable-bench/src/lib.rs erga/rs/rtable-bench/src/probe.rs erga/rs/rtable-bench/src/import_memory.rs erga/rs/blake-bench/src/reference.rs]
old_names+=old.select{|a|a.fetch('name').start_with?('erga/rs/mine-bench/shaders/')}.map{|a|a.fetch('name')}
old_names+=%w[lib.rs device.rs buffer.rs command.rs encoder.rs pipeline.rs texture.rs ffi/mod.rs ffi/selectors.rs ffi/trampoline.rs].map{|n|'honeycrisp/aruminium/src/'+n}
old_names+=%w[lib.rs block.rs block/creation.rs ffi.rs].map{|n|'honeycrisp/unimem/src/'+n}
old_names -= %w[erga/rs/mine-bench/src/lib.rs erga/rs/mine-bench/src/main.rs erga/rs/mine-bench/src/texture_ffi.rs erga/rs/rtable-bench/src/table.rs]
old_names.each{|name|a=by_name.fetch(name);g=a.fetch('git');add.call('base/'+name,a.fetch('path'),[g.fetch('repo'),g.fetch('revision'),g.fetch('path')])}
primary_names=%w[primary/apple-xnu/metal-no-copy.md primary/apple-xnu/metal-wait.md primary/apple-dispatch/dispatch-threads.md primary/apple-dispatch/grid-sizes.md primary/apple-dispatch/max-group.md prior-blake/primary/metal-setbytes.md preparation/primary/abi-observation.txt preparation/primary/review-MTLComputeCommandEncoder.h.txt preparation/primary/review-MTLPixelFormat.h.txt preparation/primary/review-MTLResource.h.txt preparation/primary/review-MTLTexture.h.txt preparation/primary/review-NSObjCRuntime.h.txt preparation/primary/review-msl.txt.txt preparation/primary/review-objc.h.txt preparation/primary/replace-region.md preparation/primary/shared-storage.md preparation/primary/texture-descriptor.md prior-rtable/primary/rust-scoped.rs preparation/oracle/main.go preparation/oracle/go.mod preparation/oracle/go.sum preparation/oracle/execution.json preparation/oracle/verification.json preparation/oracle/initial-wrapper-error.json prior-rtable/primary/published-eight-byte-vector.txt preparation/component-scope.json]
primary_names.each{|name|a=by_name.fetch(name);raise 'primary drift' unless Digest::SHA256.file(a.fetch('path')).hexdigest==a.fetch('sha256');add.call(name,a.fetch('path'))}
%w[current-source.json comparison.json api-inventory.json].each{|f|add.call('evidence/'+f,r+'/'+f)}
# Complete raw streams selected for final facts; formatter pair and compilation
# boilerplate stay hash-pinned in the attached manifest and retained execution.
stream_names=%w[04-final-debug.stdout 05-release.stdout 08-nightly-docs.stdout 09-mine-verify4.stdout 09-mine-verify4.stderr 10-rtable-verify4.stdout 11-invalid-exponent.stderr 12-invalid-duration.stderr 15-workspace-tests.stdout 20-miner-difftest.stderr 21-parent-check.stderr 28-protocol-miner-tests.stdout 29-cli-difftest.stdout 30-semver-mine.stdout 30-semver-mine.stderr 31-semver-rtable.stderr 32-parent-app-test.stdout 33-semver-rtable-parent.stderr]
stream_names.each{|f|add.call('raw/'+f,r+'/logs/'+f)}
all_records=Dir.glob(r+'/logs/*.json').sort.map{|f|JSON.parse(File.read(f))}
envs=all_records.map{|a|a.fetch('environment')}.uniq
fields=%w[cwd command lock_before lock_after source_freeze_sha256]
values=fields.to_h{|key|[key,all_records.map{|a|a.fetch(key)}.uniq]}
compact=all_records.map do |a|
 item=a.reject{|k,_|k=='environment' || fields.include?(k)}.merge('environment_id'=>envs.index(a.fetch('environment')))
 fields.each{|key|item[key+'_id']=values.fetch(key).index(a.fetch(key))}
 item
end
record_pack={environments:envs,dictionaries:values,records:compact,lossless_rule:'Restore environment from environments[environment_id] and each dictionary key from dictionaries[key][record[key+_id]], removing the corresponding _id fields. Original raw JSON hashes are retained.'}
File.write(out+'/command-records.json',JSON.pretty_generate(record_pack)+"\n");add.call('evidence/command-records.json',out+'/command-records.json')
refs=(Dir.glob(r+'/logs/*')+Dir.glob(r+'/semver-inputs/**/*').select{|f|File.file?(f)}+[r+'/verification.json',p+'/review-inputs.json',p+'/freeze.json',p+'/verification.json',p+'/oracle/vectors.json',p+'/external-inventory.json',p+'/caller-inventory.json',p+'/primary/acquisition.json',p+'/primary/sdk-acquisition.json',p+'/primary/review-excerpts.json',r+'/legacy-provenance.json']).map{|f|{path:f,bytes:File.size(f),sha256:Digest::SHA256.file(f).hexdigest}}
omitted_plan_refs=old.reject{|a|primary_names.include?(a.fetch('name')) || old_names.include?(a.fetch('name'))}.map{|a|a.slice('name','path','bytes','sha256').merge(reason:'Unchanged PLAN context; omitted here because current complete source/dependency/contract bodies and changed facts are included.')}
refs += [r+'/parent-source.json', '/tmp/erga-mine-execution-verify.rb', '/tmp/erga-mine-compare.rb', '/tmp/erga-mine-overlay.rb', '/tmp/erga-mine-snapshot.rb', '/tmp/erga-mine-execution-gate.nu', '/tmp/erga-mine-paired-gate.nu'].map{|f|{path:f,bytes:File.size(f),sha256:Digest::SHA256.file(f).hexdigest}}
File.write(out+'/retained-references.json',JSON.pretty_generate(refs)+"\n");add.call('evidence/retained-references.json',out+'/retained-references.json')
header=<<~TEXT
Fresh independent CODE review of Erga mine-bench native-owner repair. Reply APPROVE or REQUEST CHANGES first; separate blockers from optional advice. Review implementation against the approved plan and actual source, not prior reviewer conclusions. No tool use, no implementation or release approval. All changed production/test/spec files are complete below; all nine unchanged shaders and directly relevant native owner/buffer/command/FFI bodies are also complete. Source files are byte-exact, JSON structurally lossless.

Base8dcb33888868d74ddfda3eeeb9bc90e58677b394. Exact Honeycrisp9cbd48070a136e24711896c930670fcff8a147fc/Strata494df7a0973ae10a6cc1c2022e644d70449a29d6 committed closure. Source snapshot6175ec74aac4ccf2493db33b694b02120d4a2ae6a87356be3803cdc8b217b7bf. Root owns audit/commit/merge; owner already requested ordinary source/spec repairs and merge. No version/release/tag/publishing is authorized. Current whole-workspace tests/fmt and tag semver are red and require decision/wip receipts; source merge is not a release.

Check safe owner lifetime, single existing native import, immutable table bindings,32-byte vector alignment, full actual backing validation, device identity, private initialized output, exclusive mutable run, exactly adjacent submit/wait and terminal completion error state. RTable read_only_buffer is unsafe with explicit no-write/no-alias-escape/completion obligations; GpuMiner calls it privately for const shader bindings only. Input tables remain initialized after completed read-only GPU work, including failure; no API implies physical pinning beyond the unchanged spec sentence. No provider-wide soundness or native Image closure claim. V9 is a separate full initialized texture copy, never a no-copy texture claim. The physical-pages clause is byte-identical to prior canon.

Inspect arithmetic and dispatch bounds, manual56-byte params, count0 validation, exact ceil(count/k) nonuniform grids and wrapping nonces. Every V1–V9 full digest matches independent preimplementation Go math/big vectors:360 batches plus18 individual digests; native tests cover odd counts/one nonce/nonzero texture y row, widths1/64, repeated owner use, diagnosticV6/V7 and distinct V8 input contents. Full literal vectors and independent generator/tool receipt are included. The task is a simplified benchmark, not Autolykos protocol. No shader/provider algorithm was changed. Native setup never skipped.

Worker errors cannot disappear when handles drop: private workers return(), publish fault flags, and stop on fault; a stop guard lives inside thread scope before spawning; all joins precede publication with panic/main-error/overflow/reference precedence. CPU workers get immutable slices, GPU stays on caller thread. Check spawn/panic/error/counter cases and source-only limits (real OS spawn/native completion faults were not artificially fabricated).

Final focused debug/release41 passes each including17 doc tests; actual nightly compiler/rustdoc separately passes17 diagnostic-code compile failures; strict Clippy/private docs/owned format and bounded verify4 pass. Whole-workspace check/release build/strict Clippy now pass; exact-parent variants fail on eight obsolete mine field accesses. Workspace tests newly reach two existing chime overflow panics; targeted exact-parent app tests reproduce both. Remaining138 fmt sections equal parent154 after exclusion only of the two changed mine entry files. Tag semver12 mine major lint classes and9 prior RTable classes; incremental RTable semver against actual parent passes229/31skip. No API compatibility concealment. Seven bounded protocol/miner tests and512-nonce difftest pass, not whole protocol/rung closure.

Known evidence limits are explicit: initial exploratory check01 preformat overlay body was not retained, so it cannot be source-replayed; all final commands have complete source capsules. Wrong package difftest20 was a harness error (library has no bin); correct29 passes. Parent raw record source_freeze_sha256 is the common candidate-comparison overlay identity; exact parent-source.json and comparison verifier separately pin all137 executed parent files. Do not attribute candidate source to parent commands. Historical semver baseline is compile-only tagv0.30.0 plus its exact compatible provider, with disclosed lock-only removal of unimem libc; no old raw owner executed.

To keep this review bounded, repeated build progress, unchanged historical before-bodies, the two large full formatter streams, parent full-file manifest, general policy/audit context, full lock/manifests, verification harnesses and primary acquisition originals are retained/hash-pinned rather than reprinted. All33 command records are losslessly represented with shared environment dictionaries, selected full streams show every material result/error, and verification scripts show byte-exact unchanged-file/formatter/parent checks. Omission is explicit; do not claim inspection of absent full originals. No hidden rewritten outcome or four-vendor convergence claim.
TEXT
File.write(out+'/review-inputs.json',JSON.pretty_generate(rows)+"\n")
brief=header.b+rows.each_with_index.map{|a,i|"\n===== INPUT #{i+1}: #{a[:name]} =====\nSHA256: #{a[:sha256]}\nENCODING: #{a[:encoding]}\nCONTENT-BEGIN\n".b+parts[i]+"\nCONTENT-END\n===== END INPUT #{i+1} =====\n".b}.join
File.binwrite(out+'/brief.txt',brief)
freeze={created:Time.now.utc.iso8601,inputs:rows.length,git_bodies:rows.count{|a|a[:git]},brief_bytes:brief.bytesize,brief_sha256:Digest::SHA256.hexdigest(brief),index_sha256:Digest::SHA256.file(out+'/review-inputs.json').hexdigest,source_sha256:Digest::SHA256.file(r+'/current-source.json').hexdigest}
File.write(out+'/freeze.json',JSON.pretty_generate(freeze)+"\n");puts JSON.pretty_generate(freeze)
