require 'json';require 'digest';require 'open3';require 'time'
r='/tmp/erga-mine-owner-execution';p='/tmp/erga-mine-owner-plan-v1';w='/Users/master/cyber/erga-unimem-mine-owner'
def sha(path) = Digest::SHA256.file(path).hexdigest
origins=JSON.parse(File.read(p+'/origins.json')); freeze=JSON.parse(File.read(r+'/current-source.json'));allow=freeze.fetch('files').to_h{|a|[a.fetch('path'),a.fetch('sha256')]}
unchanged=0
origins.each do |origin|
 name=origin.fetch('name'); rows=JSON.parse(File.read(p+"/#{name}-source.json"))
 rows.each do |row|
  relative=row.fetch('path'); path=r+"/source/#{name}/"+relative
  next if name=='erga' && allow.key?(relative)
  raise "changed unowned input #{name}/#{relative}" unless sha(path)==row.fetch('sha256')
  unchanged+=1
 end
end
allow.each{|relative,digest|raise 'owned source differs' unless sha(w+'/'+relative)==digest && sha(r+'/source/erga/'+relative)==digest;raise 'large Rust module' if relative.end_with?('.rs') && File.readlines(w+'/'+relative).length>500}
raise 'spec not frozen proposal' unless File.binread(w+'/specs/README.md')==File.binread(p+'/proposed/README.md')
records=Dir.glob(r+'/logs/*.json').sort.map do |path|
 rec=JSON.parse(File.read(path)); base=path.delete_suffix('.json');%w[stdout stderr].each{|kind|raise 'changed raw stream' unless sha(base+'.'+kind)==rec.fetch(kind+'_sha256')}
 raise 'lock changed' unless rec.fetch('lock_before')==rec.fetch('lock_after') && rec.fetch('lock_after')=='606817eddfdf749ea453cadcaa37838d1c9e4da820b13edf5be715377d214973'
 rec.slice('label','args','exit_code','start','end','source_freeze_sha256')
end
snapshots=Dir.glob(r+'/snapshots/*/source.json').map do |file|
 h=sha(file); raise 'snapshot named incorrectly' unless File.basename(File.dirname(file))==h
 JSON.parse(File.read(file)).fetch('files').each{|row|raise 'snapshot source differs' unless sha(File.dirname(file)+'/'+row.fetch('path'))==row.fetch('sha256')}
 h
end
# Historical v0.30.0 semver-only closure, with its matching pre-unsafe provider.
legacy=[['erga',w,'848e17e2522db2f6225ad72d9b1797f8735d26d0'],['honeycrisp','/Users/master/cyber/honeycrisp','7b148906263da5ea8aabc5ddb0e2e44ff2288ecc'],['strata','/Users/master/cyber/strata','494df7a0973ae10a6cc1c2022e644d70449a29d6']]
legacy_count=0
legacy.each do |name,repo,revision|
 names,status=Open3.capture2('git','-C',repo,'ls-tree','--name-only','-r',revision);raise 'ls-tree failed' unless status.success?
 names.lines.map(&:chomp).each do |relative|
  raw,status=Open3.capture2('git','-C',repo,'show',revision+':'+relative);raise 'git show failed' unless status.success?
  if name=='erga' && relative=='Cargo.lock'
   old="name = \"unimem\"\nversion = \"0.2.0\"\ndependencies = [\n \"crossbeam-queue\",\n \"libc\",\n \"mutants\",\n]"
   raise 'tag lock normalization changed' unless raw.include?(old)
   raw=raw.sub(old,old.sub(" \"libc\",\n",''))
  end
  raise "legacy differs #{name}/#{relative}" unless raw.b==File.binread(r+"/legacy/#{name}/"+relative)
  legacy_count+=1
 end
end
reference=JSON.parse(File.read(p+'/oracle/vectors.json'))
expected=reference.fetch('vectors').map{|v|v.values_at('rows','kind','nonce_base','count','xor').join(' ')}.join("\n")+"\n"
raise 'batch literal altered' unless expected==File.read(w+'/rs/mine-bench/tests/fixtures/batches.txt')
expected=reference.fetch('individual').map{|v|v.values_at('rows','kind','nonce','digest').join(' ')}.join("\n")+"\n"
raise 'individual literal altered' unless expected==File.read(w+'/rs/mine-bench/tests/fixtures/individual.txt')
api={removed:['GpuMinerV9','SHADER_MINE_V9 (public)','texture_ffi (public)','read_acc32','zero_acc32','cpu_mine_for','gpu_mine_for','GpuMiner::open_v1','GpuMiner::run_dual','GpuMiner public gpu/variant fields'],changed:['GpuMiner::open: borrowed Gpu and table lifetimes plus optional second table','GpuMiner::run: &mut self, no external raw buffers, Result<[u8;32]>','mine_one: derives rows from slice, removes n parameter, returns Result','cpu_accumulate: returns Result'],added:['MineVariant::V9Texture (exhaustive enum source break)','unsafe RTable::read_only_buffer','GpuMiner::variant','mine_bench::BenchError'],measured_direct_consumer:'rs/mine-bench/src/main.rs and its new private CLI modules only; prior 22-origin manifest/source inventory in PLAN'}
File.write(r+'/api-inventory.json',JSON.pretty_generate(api)+"\n")
result={verified_at:Time.now.utc.iso8601,source_base:freeze.fetch('base'),source_sha256:sha(r+'/current-source.json'),source_files:allow.length,untouched_archive_files:unchanged,legacy_committed_files:legacy_count,legacy_lock_normalization:'remove unimem libc dependency only to match exact historical compatible provider; compile-only',records:records.length,raw_streams:records.length*2,source_snapshots:snapshots,exploratory_earliest_snapshot_missing:records.select{|g| !snapshots.include?(g['source_freeze_sha256'])}.map{|g|g['label']},spec_equals_reviewed_proposal:true,fixture_batches:360,fixture_individual:18,all_changed_rust_at_most_500_lines:true,records_summary:records}
File.write(r+'/verification.json',JSON.pretty_generate(result)+"\n")
puts JSON.generate(result.reject{|k,_|k==:records_summary})
