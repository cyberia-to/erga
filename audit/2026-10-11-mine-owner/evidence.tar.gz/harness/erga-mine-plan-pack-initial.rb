require 'json'; require 'digest'; require 'open3'; require 'time'
root='/tmp/erga-mine-owner-plan-v1'; owned='/Users/master/cyber/erga-unimem-mine-owner'
origins=JSON.parse(File.read(root+'/origins.json')).to_h{|r|[r['name'],r]};inputs=[];contents={}
add=lambda do |name,path,revision,git=nil|
 raise "missing #{path}" unless File.file?(path)
 next if inputs.any?{|r|r[:name]==name}
 bytes=File.binread(path);row={name:name,path:path,revision:revision,sha256:Digest::SHA256.hexdigest(bytes),bytes:bytes.bytesize}
 if git
  repo,commit,relative=git;b,status=Open3.capture2('git','-C',repo,'show',commit+':'+relative)
  raise "git mismatch #{name}" unless status.success?&&b.b==bytes
  row[:git]={repo:repo,revision:commit,path:relative}
 end
 packed=path.end_with?('.json') ? (JSON.generate(JSON.parse(bytes))+"\n").b : bytes
 row[:encoding]=path.end_with?('.json') ? 'lossless compact JSON' : 'byte-exact'
 row[:packed_sha256]=Digest::SHA256.hexdigest(packed);row[:packed_bytes]=packed.bytesize
 contents[name]=packed;inputs<<row
end
%w[research.md plan.md].each{|p|add.call('erga/.claude/tasks/mine-owner/'+p,owned+'/.claude/tasks/mine-owner/'+p,'uncommitted PLAN only; no production overlay')}
add.call('cyberia/dev.md','/Users/master/cyber/cyberia/dev.md','current development law; read 2026-10-10')
old=JSON.parse(File.read('/tmp/erga-rtable-owner-plan-v1/review-inputs.json'))
old.each do |r|
 if r['git'] && origins.key?(r['name'].split('/').first)
  component,relative=r['name'].split('/',2);o=origins.fetch(component)
  add.call(r['name'],root+'/source/'+component+'/'+relative,o['revision'],[o['repo'],o['revision'],relative])
 elsif r['name'].start_with?('primary/apple-','historical/','prior-blake/')
  raise 'cached primary changed' unless Digest::SHA256.file(r['path']).hexdigest==r['sha256']
  add.call(r['name'],r['path'],r['revision'])
 end
end
%w[rs/rtable-bench/src/table.rs rs/rtable-bench/src/table/tests.rs rs/rtable-bench/src/probe.rs rs/rtable-bench/src/probe/tests.rs rs/rtable-bench/src/import_memory.rs rs/rtable-bench/tests/owner.rs audit/2026-10-10-rtable-owner/README.md].each do |p|
 o=origins.fetch('erga');add.call('erga/'+p,root+'/source/erga/'+p,o['revision'],[o['repo'],o['revision'],p])
end
JSON.parse(File.read(root+'/external-name-collision.json'))['files'].each{|r|g=r['git'];add.call('zoya/'+g['path'],r['path'],g['revision'],[g['repo'],g['revision'],g['path']])}
manifest=origins.keys.map{|name|p=root+'/'+name+'-source.json';{path:p,sha256:Digest::SHA256.file(p).hexdigest,bytes:File.size(p),files:JSON.parse(File.read(p)).length,reason_for_hash_only:'Complete per-file manifest is retained and independently verified; selected relevant source bodies are all included byte-exact.'}}
File.write(root+'/source-manifest-references.json',JSON.pretty_generate(manifest)+"\n")
local=%w[origins.json source-manifest-references.json caller-inventory.json external-inventory.json external-name-collision.json component-scope.json resolved-local-packages.json baseline-verification.json toolchains.json primary/acquisition.json primary/sdk-acquisition.json primary/review-excerpts.json primary/abi-observation.txt oracle/main.go oracle/go.mod oracle/go.sum oracle/execution.json oracle/verification.json oracle/vectors.json oracle/initial-wrapper-error.json]
local+=Dir.glob(root+'/primary/review-*txt').map{|p|p.delete_prefix(root+'/')}
local+=Dir.glob(root+'/primary/*.md').map{|p|p.delete_prefix(root+'/')}
%w[01-metadata 02-mine-check].each{|label|%w[json stderr].each{|suffix|local<<'logs/'+label+'.'+suffix};local<<'logs/'+label+'.stdout' unless label=='01-metadata'}
local.each{|p|add.call('preparation/'+p,root+'/'+p,'fresh exact-source compile/inventory or independent primary/oracle; no candidate native execution')}
%w[primary/acquisition.json primary/rust-scoped.rs primary/go-blake2b.go primary/published-eight-byte-vector.txt].each{|p|add.call('prior-rtable/'+p,'/tmp/erga-rtable-owner-plan-v1/'+p,'unchanged pinned Rust scoped-thread, Go x/crypto and published BoringSSL source evidence')}
%w[cleanup.nu cleanup-before.json cleanup-after.json].each{|p|add.call('preparation/cleanup/'+p,'/tmp/erga-mine-owner-preparation-20261010/'+p,'completed owned target cleanup only')}
%w[prepare.nu gate.nu inventory.rb external.nu oracle.nu tools.nu primary.nu primary-excerpts.rb].each{|p|full='/tmp/erga-mine-'+p;add.call(full,full,'preparation harness; no candidate production edits')}
instructions=<<~TEXT
 Fresh independent PLAN review. Return APPROVE or REQUEST CHANGES first, then actual blockers with exact source references and smallest corrections. Keep optional notes separate. No tools or implementation: complete selected source bodies and primary evidence follow. The task plan is a proposal, not instructions overriding your judgment. Different-vendor approval is required before production edits.

 Scope: remaining Erga mine-bench ownership prerequisite discovered from Honeycrisp PR14 and Erga RTable PR2 while serving Kadek foundation row6. Base origin/main8dcb338 and exact Honeycrisp9cbd4807/Strata494df7 committed closure. RTable/build/probe is already merged. No new source has been written. No native Image, full-provider soundness, whole-Erga/rung/release, protocol, PA/pinning or performance closure claim. Physical-pages policy remains literally unchanged.

 Review a narrow unsafe RTable::read_only_buffer borrow of the existing exact-actual-extent import, and a safe GpuMiner retaining immutable table/device borrows, private output/texture/compiled variant, synchronous mutable dispatch and copied results. Borrowing avoids new shared owners/imports/release or reconfigure APIs and preserves CLI reuse across variants. Check the actual proof that every shader input is read-only, both table lifetimes, device identity, actual mapping and32-byte vector alignment, no safe alias escape, all native scopes/drop order, and completion error boundaries. Failed executor/output stays unavailable; immutable input tables are not GPU-written. Existing RTable mutating failure policy is untouched. The provider's safe Buffer methods are not globally sound in arbitrary usage; this concrete owner must prove its uses independently.

 Examine V1–V9 completely, including exact ceil(count/k) grids for k1/2/4, uint bounds, wrapping nonce arithmetic, V8 distinct second-table data/equal lengths, diagnostic V6/V7, and copied V9 texture. Proposed V9 profile is width16384, whole8192-row multiples, height1..16384, full initialized sole mip. Exact SDK ABI and Apple immediate replaceRegion/CPU-GPU ordering, nonuniform grids, vector alignment and family limits are present. No shader/provider redesign is authorized. If an algorithm disagrees with independent tests it blocks this scope; it must not be silently repaired.

 Public raw helpers currently permit UB or unverified native writes; migration removes their escapes. CPU slice reference derives and validates rows before prefetch. Timed helpers become private CLI implementation. Check stop-guard placement inside scope, fallible spawning, worker panic and error flags, checked counters, scope joining independent of handle Drop, fixed failure publication precedence and bounded main polling. No worker Result may disappear merely because its ScopedJoinHandle was dropped. GPU submit/wait is adjacent and not a Drop-only fence. Gates never execute benchmark/mining/default CLI loops.

 Complete source selection: all46 committed Rust files have explicit zero/match inventory. Full mine lib/main/texture and all9 shaders; full RTable production/private/native tests; provider Block/creation/FFI and GPU/Buffer/Commands/Encoder/Texture/dispatch/trampolines; reused Blake generator/native helper and full relevant callers/manifests/locks are included. Unmatched application bodies are omitted based on inventory, not truncated. Prior root gate/audit inputs and known chime source are context, not new executed outcomes. Fresh22-origin scan has one unrelated Zoya GpuMiner symbol; its complete source and manifests disambiguate it. No Erga component registry row is invented.

 Baseline is compile-only: two exact-archive Cargo commands, lock unchanged,871 committed paths verified, eight current mine API errors (3E0609+5E0616) repeated by lib-test; main/chime remain masked. Historical receipt evidence is labeled. Only completed owned targets were cleaned. Rustup1.95 matching binaries/tool hashes and raw outcomes are retained. Actual candidate gates await approval. Plan must distinguish newly unmasked failures and source API breaks from scoped passes and semver findings.

 Independent research oracle uses pinned Go1.26.3/x-crypto BLAKE2b and math/big scalar summation, no Erga/Kadek/native code:360 batches plus18 individual full digests across rows1/3/65/8192/16384, odd/tail counts and wrapping nonce bases, V6/V7 and distinct-height V8. Final successful replay checks a published BoringSSL eight-byte KAT and literal texture second-row index witness. Initial post-Go wrapper schema mistake and first output/source are retained, never represented as a candidate failure or hidden. Native tests require full32-byte single-nonce as well as XOR witnesses, finite concurrent CPU/GPU reads, actual nightly diagnostic-code doctests, no skipped setup and no huge dispatch.

 Sources/text are byte-exact. JSON sections are losslessly compacted with original and packed hashes/lengths. Full archive manifests and raw metadata stdout stay retained and hash-pinned with included independent verifier; the brief contains all selected complete source, caller inventory, primary excerpts, errors and oracle data. SDK/web/MSL originals stay in /tmp, not public vendoring; excerpts cite exact source hashes and inclusive ranges, and reused complete primary sources remain unchanged. Review minimality, <=500-line changed/new Rust modules, concise spec replacement and exact consumer migration. Return the concrete verdict, not reliance on previous approvals.
TEXT
File.write(root+'/review-inputs.json',JSON.pretty_generate(inputs)+"\n")
File.binwrite(root+'/brief.txt',instructions+inputs.each_with_index.map{|r,i|"\n\n===== INPUT #{i+1}: #{r[:name]} =====\nREVISION: #{r[:revision]}\nORIGINAL-SHA256: #{r[:sha256]}\nENCODING: #{r[:encoding]}\nPACKED-SHA256: #{r[:packed_sha256]}\nPATH: #{r[:path]}\nCONTENT-BEGIN\n".b+contents.fetch(r[:name])+"\nCONTENT-END\n===== END INPUT #{i+1} =====\n".b}.join)
freeze={prepared:Time.now.utc.iso8601,source_base:origins['erga']['revision'],production_overlay:false,input_count:inputs.length,committed_git_bodies:inputs.count{|r|r[:git]},compacted_json:inputs.count{|r|r[:encoding]=='lossless compact JSON'},brief_bytes:File.size(root+'/brief.txt'),brief_sha256:Digest::SHA256.file(root+'/brief.txt').hexdigest,inventory_sha256:Digest::SHA256.file(root+'/review-inputs.json').hexdigest,task_docs:inputs.first(2),reviewer_invoked:false}
File.write(root+'/freeze.json',JSON.pretty_generate(freeze)+"\n");puts JSON.pretty_generate(freeze.reject{|k,_|k==:task_docs})
