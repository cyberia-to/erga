require 'json';require 'digest';require 'time'
r='/tmp/erga-mine-owner-execution'
def text(path)=File.binread(path).force_encoding('UTF-8')
def sections(raw)
 raw.split(/(?=^Diff in )/).reject(&:empty?).map do |part|
  first=part.lines.first.chomp
  raise 'unexpected fmt prefix' unless first.start_with?('Diff in ')
  [first,part]
 end
end
normalize=lambda{|s|s.gsub(%r{/(private/)?tmp/erga-mine-owner-execution/(source|parent)/erga/},'ERGA/')}
c=sections(normalize.call(text(r+'/logs/18-workspace-fmt.stdout')))
p=sections(normalize.call(text(r+'/logs/25-parent-fmt.stdout')))
owned=JSON.parse(File.read(r+'/current-source.json')).fetch('files').map{|x|x.fetch('path')}
filter=lambda{|xs|xs.reject{|head,_|owned.any?{|path|head.start_with?('Diff in ERGA/'+path+':')}}}
raise 'formatter differences outside changed paths' unless filter.call(c)==filter.call(p)
app=lambda{|name|s=text(r+'/logs/'+name+'.stdout');{tests:s.scan(/^test ([^ ]+) \.\.\. (ok|FAILED)$/).sort,panics:s.scan(/panicked at (rs\/app\/src\/chime\.rs:\d+:\d+):\nattempt to multiply with overflow/).flatten.sort}}
# Candidate workspace stdout also contains earlier crates; restrict the app names.
ca=app.call('15-workspace-tests');pa=app.call('32-parent-app-test');ca[:tests].select!{|name,_|name.start_with?('chime::','store::')};raise 'app failure differs' unless ca==pa
parent_hashes=JSON.parse(File.read('/tmp/erga-mine-owner-plan-v1/erga-source.json'))
parent_hashes.each{|row|raise 'parent modified' unless Digest::SHA256.file(r+'/parent/erga/'+row.fetch('path')).hexdigest==row.fetch('sha256')}
parent_source={revision:'8dcb33888868d74ddfda3eeeb9bc90e58677b394',files:parent_hashes}
File.write(r+'/parent-source.json',JSON.pretty_generate(parent_source)+"\n")
result={verified_at:Time.now.utc.iso8601,command:['ruby',__FILE__],candidate_fmt_sections:c.length,parent_fmt_sections:p.length,unchanged_fmt_sections:filter.call(c).length,unchanged_fmt_bytes_equal_after_exact_root_normalization:true,excluded_fmt_paths:owned.select{|path|p.any?{|head,_|head.start_with?('Diff in ERGA/'+path+':')}},app_test_command_pair:['15-workspace-tests','32-parent-app-test'],app_failure_pair:pa,parent_committed_files_verified:parent_hashes.length,parent_source_sha256:Digest::SHA256.file(r+'/parent-source.json').hexdigest,source_attribution_note:'Parent commands name /parent/erga; common source_freeze_sha256 in raw command receipts names the candidate overlay under comparison, not the executed parent. This independently verified parent-source.json supplies their exact source identity.',harness_error:{label:'20-miner-difftest',actual:'cargo run -p erga-miner has no binary target',correction:'29-cli-difftest uses erga-cli --bin erga; exit0,512 exact nonce results'},unmasked_test_failures_only:true}
File.write(r+'/comparison.json',JSON.pretty_generate(result)+"\n");puts JSON.pretty_generate(result)
