let root = '/tmp/erga-mine-owner-plan-v1'
let directory = ($root | path join oracle)
cd $directory
let environment = {GOWORK: 'off', GOTOOLCHAIN: 'local', GOPROXY: 'off', GOSUMDB: 'off', GOCACHE: ($root | path join go-cache), GOMAXPROCS: '2'}
let command = '/opt/homebrew/bin/go'
let args = ['run' '-mod=readonly' '.']
let start = (date now | format date '%+')
let result = (with-env $environment { run-external $command ...$args | complete })
$result.stdout | save --force ($directory | path join vectors.json)
$result.stderr | save --force ($directory | path join stderr.txt)
{command: $command, args: $args, environment: $environment, cwd: $directory, start: $start, end: (date now | format date '%+'), exit_code: $result.exit_code, tool_sha256: (open --raw $command | hash sha256), version: (^go version | complete), stdout_sha256: ($result.stdout | hash sha256), stderr_sha256: ($result.stderr | hash sha256), crypto_origin: (open /Users/master/go/pkg/mod/cache/download/golang.org/x/crypto/@v/v0.48.0.info), crypto_ziphash: (open --raw /Users/master/go/pkg/mod/cache/download/golang.org/x/crypto/@v/v0.48.0.ziphash), source_sha256: (open --raw main.go | hash sha256), manifest_sha256: (open --raw go.mod | hash sha256), lock_sha256: (open --raw go.sum | hash sha256)} | to json | save --force ($directory | path join execution.json)
if $result.exit_code != 0 { error make {msg: $result.stderr} }
let parsed = ($result.stdout | from json)
if ($parsed.vectors | length) != 360 or ($parsed.individual | length) != 18 { error make {msg: 'oracle count mismatch'} }
if $parsed.published_row != '77065d25b622a8251094d869edf6b4e9ba0708a8db1f239cb68e4eeb45851621' { error make {msg: 'published vector mismatch'} }
if ($parsed.texture_indices_nonce0_rows16384 | where { $in >= 8192 } | length) == 0 { error make {msg: 'texture witness never reads second row'} }
let zero = ($parsed.vectors | where count == 0)
if ($zero | where xor != ('0' | fill -w 64 -c '0') | length) != 0 { error make {msg: 'nonzero empty XOR'} }
{vectors: ($parsed.vectors | length), individual: ($parsed.individual | length), empty_cases: ($zero | length), no_erga_code_used: true, scalar_sum: 'math/big reduced to low256 bits', production_result: false, published_eight_byte_kat: true, texture_second_row_selected: true} | to json | save --force ($directory | path join verification.json)
print $"independent Go oracle: exit ($result.exit_code)"
