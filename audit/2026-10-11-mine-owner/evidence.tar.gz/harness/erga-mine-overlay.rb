require 'fileutils'; require 'json'; require 'digest'; require 'time'
w='/Users/master/cyber/erga-unimem-mine-owner';r='/tmp/erga-mine-owner-execution'
paths=Dir.chdir(w){Dir.glob('rs/mine-bench/src/**/*.rs')+['rs/rtable-bench/src/table.rs','rs/rtable-bench/src/table/tests.rs','specs/README.md']+Dir.glob('rs/mine-bench/tests/**/*').select{|p|File.file?(p)}}
paths.each{|p|FileUtils.mkdir_p(File.dirname(r+'/source/erga/'+p));FileUtils.cp(w+'/'+p,r+'/source/erga/'+p)}
rows=paths.map{|p|{path:p,sha256:Digest::SHA256.file(w+'/'+p).hexdigest}}
File.write(r+'/current-source.json',JSON.pretty_generate({time:Time.now.utc.iso8601,base:'8dcb33888868d74ddfda3eeeb9bc90e58677b394',files:rows})+"\n")
