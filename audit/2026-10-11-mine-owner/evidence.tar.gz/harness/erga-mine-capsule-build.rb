require 'json'
require 'digest'
require 'fileutils'
require 'open3'
require 'time'

EX = '/tmp/erga-mine-owner-execution'
PL = '/tmp/erga-mine-owner-plan-v1'
CAP = '/tmp/erga-mine-owner-capsule-v1'
OWN = '/Users/master/cyber/erga-unimem-mine-owner'
AUD = OWN + '/audit/2026-10-11-mine-owner'
raise 'capsule exists' if File.exist?(CAP)
FileUtils.mkdir_p(CAP)
FileUtils.mkdir_p(AUD)
$copies = []
def copy(from, relative)
  to = CAP + '/' + relative
  FileUtils.mkdir_p(File.dirname(to))
  FileUtils.cp(from, to)
  $copies << {original: from, retained: relative, sha256: Digest::SHA256.file(to).hexdigest}
end
def copy_tree(from, relative)
  Dir.glob(from + '/**/*', File::FNM_DOTMATCH).select { |p| File.file?(p) }.sort.each do |p|
    copy(p, relative + '/' + p.delete_prefix(from + '/'))
  end
end
def write(relative, value)
  path = CAP + '/' + relative
  FileUtils.mkdir_p(File.dirname(path))
  File.write(path, JSON.pretty_generate(value) + "\n")
end
def run(*args, env: {})
  stdout, stderr, status = Open3.capture3(env, *args)
  raise "#{args.inspect}: #{stderr}" unless status.success?
  stdout
end

%w[api-inventory.json comparison.json current-source.json parent-source.json legacy-provenance.json verification.json tag-Cargo.lock].each { |p| copy(EX + '/' + p, 'execution/' + p) }
%w[logs snapshots semver-inputs].each { |p| copy_tree(EX + '/' + p, 'execution/' + p) }
%w[origins.json erga-source.json honeycrisp-source.json strata-source.json source-manifest-references.json caller-inventory.json external-inventory.json external-name-collision.json component-scope.json components.toml resolved-local-packages.json baseline-verification.json toolchains.json Cargo.lock.origin freeze.json review-inputs.json verification.json resume-verification-20261011.json brief.txt].each { |p| copy(PL + '/' + p, 'plan/' + p) }
%w[logs proposed].each { |p| copy_tree(PL + '/' + p, 'plan/' + p) }
copy_tree(PL + '/oracle', 'oracle')
copy_tree(OWN + '/.claude/tasks/mine-owner', 'task')
%w[acquisition.json sdk-acquisition.json review-excerpts.json abi-observation.txt].each { |p| copy(PL + '/primary/' + p, 'primary/' + p) }
Dir.glob(PL + '/primary/review-*.txt').sort.each { |p| copy(p, 'primary/' + File.basename(p)) }
copy('/tmp/erga-rtable-owner-plan-v1/primary/acquisition.json', 'primary/inherited-rtable-acquisition.json')
copy('/tmp/erga-mine-owner-plan-v1-review.txt', 'reviews/plan-opus-quota.txt')
copy('/tmp/erga-mine-owner-plan-v1-grok-review.txt', 'reviews/plan-grok.txt')
%w[v1 v2].each do |version|
  dir = '/tmp/erga-mine-owner-code-' + version
  Dir.glob(dir + '/*').select { |p| File.file?(p) }.sort.each { |p| copy(p, 'reviews/code-' + version + '/' + File.basename(p)) }
end
# Original scripts preserve exact commands and deliberate earlier failures.
Dir.glob('/tmp/erga-mine-*.{rb,nu}').sort.reject { |p| p.include?('capsule') || p.include?('audit-replay') }.each { |p| copy(p, 'harness/' + File.basename(p)) }

source = JSON.parse(File.read(EX + '/current-source.json'))
paths = source.fetch('files').map { |r| r.fetch('path') }
source.fetch('files').each { |r| raise 'live source differs' unless Digest::SHA256.file(OWN + '/' + r.fetch('path')).hexdigest == r.fetch('sha256') }
base = source.fetch('base')
before = paths.map do |path|
  bytes, _, status = Open3.capture3('git', '-C', OWN, 'show', base + ':' + path)
  if status.success?
    destination = 'source/parent-before/' + path
    FileUtils.mkdir_p(File.dirname(CAP + '/' + destination))
    File.binwrite(CAP + '/' + destination, bytes)
    {path: path, existed: true, retained: destination, sha256: Digest::SHA256.hexdigest(bytes)}
  else
    {path: path, existed: false}
  end
end
write('source/parent-before.json', {revision: base, files: before})
index_path = '/tmp/erga-mine-capsule-index-' + Process.pid.to_s
begin
  env = {'GIT_INDEX_FILE' => index_path}
  run('git', '-C', OWN, 'read-tree', base, env: env)
  run('git', '-C', OWN, 'add', '--', *paths, env: env)
  patch = run('git', '-C', OWN, 'diff', '--cached', '--binary', base, '--', *paths, env: env)
  File.binwrite(CAP + '/source/candidate.diff', patch)
ensure
  FileUtils.rm_f(index_path)
end
File.write(CAP + '/source/patch-command.json', JSON.pretty_generate({base: base, paths: paths, command: ['git', 'diff', '--cached', '--binary', base, '--', *paths], index: 'temporary alternate index initialized from base; ordinary worktree index untouched', source_sha256: Digest::SHA256.file(EX + '/current-source.json').hexdigest}) + "\n")

records = Dir.glob(EX + '/logs/*.json').sort.map { |p| JSON.parse(File.read(p)) }
parent_hash = Digest::SHA256.file(EX + '/parent-source.json').hexdigest
mapping = records.map do |row|
  parent = row.fetch('cwd').end_with?('/parent/erga')
  hash = parent ? parent_hash : row.fetch('source_freeze_sha256')
  snapshot = 'execution/snapshots/' + hash + '/source.json'
  {label: row.fetch('label'), executed_source: parent ? 'exact committed parent' : 'candidate overlay', source_manifest: parent ? 'execution/parent-source.json' : (File.exist?(CAP + '/' + snapshot) ? snapshot : nil), source_sha256: hash, bodies_retained: parent ? 'modified-path before bodies; full parent file hashes and Git revision retained' : (File.exist?(CAP + '/' + snapshot) ? 'all overlay bodies retained' : 'exploratory preformat body snapshot not retained'), historical_baseline: row.fetch('args').include?('semver-checks') ? (row.fetch('label') == '33-semver-rtable-parent' ? 'parent-source.json' : 'legacy-provenance.json legacy entry; normalized tag lock') : nil}
end
write('execution/command-source-map.json', mapping)
write('execution/attribution-correction.json', {
  executed_parent_revision: base,
  parent_source_sha256: parent_hash,
  evidence: ['execution/parent-source.json', 'execution/comparison.json', 'execution/logs/21-parent-check.json', 'execution/logs/32-parent-app-test.json'],
  raw_record_limitation: 'Parent command source_freeze_sha256 names the candidate comparison overlay; command-source-map.json instead binds the actual executed parent through parent-source.json.',
  stale_metadata: 'The original legacy-provenance.json parent entry incorrectly retains tag 848e17e2522db2f6225ad72d9b1797f8735d26d0 and fmt-only purpose. Preserve it as an original preparation receipt, not the executed-parent identity. Its legacy entry remains the compile-only semver baseline.',
  original_preserved: true
})
gate_index = records.map do |r|
  r.slice('label', 'command', 'args', 'exit_code', 'stdout_sha256', 'stderr_sha256').merge('source' => mapping.find { |m| m[:label] == r.fetch('label') })
end
write('execution/gates.json', gate_index)
FileUtils.cp(CAP + '/execution/gates.json', AUD + '/gates.json')
FileUtils.cp(EX + '/current-source.json', AUD + '/source-freeze.json')

# Independently verify each retained review body and record its byte offset.
packs = [['plan', 'plan', 'approved PLAN'], ['code-v1', 'reviews/code-v1', 'draft, never submitted'], ['code-v2', 'reviews/code-v2', 'submitted; final CODE verdict owned by root']]
pack_index = packs.map do |name, relative, status|
  dir = CAP + '/' + relative
  inputs = JSON.parse(File.read(dir + '/review-inputs.json'))
  body = File.binread(dir + '/brief.txt')
  freeze = JSON.parse(File.read(dir + '/freeze.json'))
  raise 'pack identity' unless Digest::SHA256.hexdigest(body) == freeze.fetch('brief_sha256')
  cursor = 0
  sections = inputs.each_with_index.map do |entry, i|
    marker = "===== INPUT #{i + 1}: #{entry.fetch('name')} =====\n".b
    marker_offset = body.index(marker, cursor) or raise 'section marker'
    start = body.index("CONTENT-BEGIN\n".b, marker_offset) + 14
    bytes = body.byteslice(start, entry.fetch('packed_bytes'))
    raise 'packed section hash' unless Digest::SHA256.hexdigest(bytes) == entry.fetch('packed_sha256')
    ending = "\nCONTENT-END\n===== END INPUT #{i + 1} =====\n".b
    cursor = start + bytes.bytesize
    raise 'section ending' unless body.byteslice(cursor, ending.bytesize) == ending
    cursor += ending.bytesize
    {number: i + 1, name: entry.fetch('name'), offset: start, length: bytes.bytesize, sha256: entry.fetch('packed_sha256'), encoding: entry.fetch('encoding')}
  end
  raise 'pack suffix' unless cursor == body.bytesize
  {name: name, status: status, brief: relative + '/brief.txt', index: relative + '/review-inputs.json', freeze: relative + '/freeze.json', bytes: body.bytesize, sha256: Digest::SHA256.hexdigest(body), sections: sections}
end
write('reviews/pack-sections.json', pack_index)
write('reviews/identity.json', {
  implementation_vendor: 'OpenAI Codex',
  plan: {vendor: 'xAI', model_requested: 'grok-4.7', verdict: 'APPROVE', raw: 'reviews/plan-grok.txt', notice: 'Raw reviewer auto-compaction notices retained; no claim of uncompacted review or four-vendor convergence.', evidence_basis: 'Root reported fresh independent launch and read complete result.'},
  failed_plan_attempt: {vendor: 'Anthropic', model_reported: 'Opus', exit_code: 1, raw: 'reviews/plan-opus-quota.txt', classification: 'availability failure; monthly quota exhausted; no verdict'},
  code_v1: 'draft never submitted',
  code_v2: {vendor: 'xAI', model_requested: 'grok-4.7', verdict: 'pending root-owned final review', invocation: 'reviews/code-v2/review-invocation.json'},
  acceptance: 'Root owns final CODE sidecars, audit acceptance, commit, PR and merge. Current red gates require decision/wip and do not establish release readiness.'
})
write('retained-original-paths.json', $copies)
write('omissions.json', {
  omitted_bodies: ['full Apple SDK header originals and Metal PDF/text originals', 'full upstream source archives and tool/module/build caches', 'unmodified parent/provider file bodies not selected by review packs', 'original preformat exploratory check01 source bodies were never retained'],
  retained: ['Exact complete PLAN and both CODE briefs, indexes and byte offsets', 'All command JSON and raw streams including errors and early outcomes', 'Every candidate final and intermediate source body plus modified parent before bodies and full patch', 'Full committed file manifests/pins; all original oracle generators/literals/receipts; primary hashes/excerpts/acquisition receipts'],
  source_reconstruction: 'Fetch the named committed Erga/Honeycrisp/Strata revisions, verify plan source manifests, then apply source/candidate.diff. semver legacy uses exact legacy pins plus the disclosed one-line lock normalization.',
  review_scope: 'Reviewers could inspect only the supplied brief. Retention or a hash does not prove review of an omitted original.',
  native_scope: 'Portable replay checks evidence integrity and relationships, not native execution, SDK original acquisition or upstream Git byte comparisons. Private completion/spawn fault injection does not demonstrate real native GPU/OS fault occurrence.'
})
puts JSON.pretty_generate({capsule: CAP, audit: AUD, records: records.length, packs: pack_index.map { |p| p.slice(:name, :status, :bytes, :sha256) }})
