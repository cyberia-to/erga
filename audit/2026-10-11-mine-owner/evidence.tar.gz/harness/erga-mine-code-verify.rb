require 'json';require 'digest';require 'open3';require 'time'
r='/tmp/erga-mine-owner-code-v2';e='/tmp/erga-mine-owner-execution'
index=JSON.parse(File.read(r+'/review-inputs.json'));freeze=JSON.parse(File.read(r+'/freeze.json'));body=File.binread(r+'/brief.txt');cursor=0;git_count=0
raise 'brief identity' unless Digest::SHA256.hexdigest(body)==freeze.fetch('brief_sha256')
raise 'index identity' unless Digest::SHA256.file(r+'/review-inputs.json').hexdigest==freeze.fetch('index_sha256')
index.each_with_index do |entry,i|
 marker="===== INPUT #{i+1}: #{entry.fetch('name')} =====\n".b
 start=body.index(marker,cursor) or raise 'missing section'
 content=body.index("CONTENT-BEGIN\n".b,start)+14
 packed=body.byteslice(content,entry.fetch('packed_bytes'));cursor=content+packed.bytesize
 ending="\nCONTENT-END\n===== END INPUT #{i+1} =====\n".b
 raise 'section end' unless body.byteslice(cursor,ending.bytesize)==ending;cursor+=ending.bytesize
 original=File.binread(entry.fetch('path'))
 raise 'input identity' unless original.bytesize==entry.fetch('bytes') && Digest::SHA256.hexdigest(original)==entry.fetch('sha256')
 raise 'packed identity' unless Digest::SHA256.hexdigest(packed)==entry.fetch('packed_sha256')
 if entry.fetch('encoding')=='lossless compact JSON'
  raise 'JSON differs' unless JSON.parse(original)==JSON.parse(packed)
 else
  raise 'body differs' unless original==packed
 end
 if (g=entry['git'])
  b,s=Open3.capture2('git','-C',g.fetch('repo'),'show',g.fetch('revision')+':'+g.fetch('path'));raise 'Git differs' unless s.success? && b.b==original;git_count+=1
 end
end
raise 'suffix content' unless cursor==body.bytesize
records=JSON.parse(File.read(r+'/command-records.json'))
records.fetch('records').each do |row|
 restored=row.dup;restored['environment']=records.fetch('environments').fetch(restored.delete('environment_id'))
 records.fetch('dictionaries').each{|name,values|restored[name]=values.fetch(restored.delete(name+'_id'))}
 raw=JSON.parse(File.read(e+'/logs/'+restored.fetch('label')+'.json'))
 raise 'command record lossy' unless restored==raw
end
refs=JSON.parse(File.read(r+'/retained-references.json'))
refs.each{|row|raise 'retained reference differs' unless File.size(row.fetch('path'))==row.fetch('bytes') && Digest::SHA256.file(row.fetch('path')).hexdigest==row.fetch('sha256')}
production=JSON.parse(File.read(e+'/current-source.json')).fetch('files')
raise 'candidate omission' unless production.all?{|p|index.any?{|row|row.fetch('name')=='candidate/'+p.fetch('path') && row.fetch('sha256')==p.fetch('sha256')}}
receipt={verified:Time.now.utc.iso8601,command:['ruby',__FILE__],inputs:index.length,full_git_bodies:git_count,complete_candidate_files:production.length,lossless_command_records:records.fetch('records').length,retained_hash_references:refs.length,brief_bytes:body.bytesize,brief_sha256:Digest::SHA256.hexdigest(body),index_sha256:Digest::SHA256.file(r+'/review-inputs.json').hexdigest,source_sha256:Digest::SHA256.file(e+'/current-source.json').hexdigest}
File.write(r+'/verification.json',JSON.pretty_generate(receipt)+"\n");puts JSON.pretty_generate(receipt)
