let root = '/tmp/erga-mine-owner-plan-v1/primary'
mkdir $root
mut receipts = []
for row in [
 {name: 'replace-region.md', url: 'https://developer.apple.com/documentation/metal/mtltexture/replace(region:mipmaplevel:withbytes:bytesperrow:).md'},
 {name: 'texture-descriptor.md', url: 'https://developer.apple.com/documentation/metal/mtltexturedescriptor/texture2ddescriptor(pixelformat:width:height:mipmapped:).md'},
 {name: 'shared-storage.md', url: 'https://developer.apple.com/documentation/metal/mtlstoragemode/shared.md'},
 {name: 'resource-sync.md', url: 'https://developer.apple.com/documentation/metal/synchronizing-cpu-and-gpu-work.md'}
] {
 let dest = ($root | path join $row.name)
 let args = ['-fL' '--retry' '2' '-o' $dest $row.url]
 let start = (date now)
 let run = (^curl ...$args | complete)
 $receipts = ($receipts | append ($row | insert args $args | insert started ($start | format date '%+') | insert finished (date now | format date '%+') | insert result $run | insert sha256 (if ($dest | path exists) {open --raw $dest | hash sha256} else {null})))
}
$receipts | to json | save ($root | path join acquisition.json)
print ($receipts | select name result.exit_code sha256)
