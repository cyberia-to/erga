require 'json';require 'digest'
root='/tmp/erga-mine-owner-plan-v1/primary'
items=[
 ['MTLTexture.h',[[1,30],[95,125],[155,220],[475,505]]],
 ['MTLPixelFormat.h',[[1,18],[88,103]]],
 ['MTLResource.h',[[51,91]]],
 ['MTLComputeCommandEncoder.h',[[145,170]]],
 ['objc.h',[[35,93]]],
 ['NSObjCRuntime.h',[[1,25]]],
 ['/tmp/xena-gpu-metal-dispatch-primary/msl.txt',[[1130,1214]]]
]
manifest=[]
items.each do |name,ranges|
 source=name.start_with?('/') ? name : File.join(root,name)
 b=File.read(source, encoding: "UTF-8");lines=b.lines;out="Primary excerpt of #{source}\nFull source SHA256 #{Digest::SHA256.hexdigest(b)}; original one-based inclusive line ranges #{ranges.inspect}.\n"
 ranges.each{|a,z| out+="\n[Original lines #{a}–#{z}]\n"+lines[(a-1)..(z-1)].join}
 dest=File.join(root,"review-#{File.basename(name)}.txt");File.write(dest,out)
 manifest<<{source:source,source_sha256:Digest::SHA256.hexdigest(b),ranges:ranges,path:dest,sha256:Digest::SHA256.hexdigest(out),bytes:out.bytesize}
end
File.write(File.join(root,'review-excerpts.json'),JSON.pretty_generate(manifest)+"\n")
File.write(File.join(root,'abi-observation.txt'),"2026-10-10, read-only compiler/SDK observation; no candidate/native execution.\nxcrun clang -dM -E -x objective-c /dev/null | rg '__OBJC_BOOL_IS_BOOL|__arm64__|__LP64__'\nexit 0\n#define __LP64__ 1\n#define __OBJC_BOOL_IS_BOOL 1\n#define __arm64__ 1\nxcrun --show-sdk-version\nexit 0\n26.4.1\nThe pinned objc.h therefore selects bool BOOL for this arm64 target. NSUInteger is unsigned long (8-byte Apple LP64); use Rust usize, and bool for mipmapped.\n")
