require 'fileutils';require 'json';require 'digest'
label=ARGV.fetch(0);r='/tmp/erga-mine-owner-execution';d=r+'/semver-inputs/'+label;FileUtils.mkdir_p(d)
paths=Dir.glob(r+'/target-semver/**/{Cargo.toml,Cargo.lock}',File::FNM_DOTMATCH).select{|p|File.file?(p)}
rows=paths.map do |p|
 relative=p.delete_prefix(r+'/target-semver/');FileUtils.mkdir_p(File.dirname(d+'/'+relative));FileUtils.cp(p,d+'/'+relative)
 {path:relative,sha256:Digest::SHA256.file(p).hexdigest}
end
File.write(d+'/inventory.json',JSON.pretty_generate(rows)+"\n")
