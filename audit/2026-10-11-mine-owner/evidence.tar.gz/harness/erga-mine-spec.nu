let root = '/tmp/erga-mine-owner-plan-v1'
let path = ($root | path join source erga specs README.md)
let original = (open --raw $path)
let before = 'Blake batches and R-tables own fully initialized backing for fixed nonzero
record counts. CPU and GPU access must address the same physical pages.
CPU views and table builds cover logical records. Private native imports remain
owned through synchronous completion; conflicting CPU/device access is excluded.
Partial table builds and failed completion make affected owners unavailable;
pre-submit rejection preserves usable input.'
let after = 'Blake batches and R-tables own fully initialized actual backing for fixed nonzero
logical record counts. CPU and GPU access must address the same physical pages.
Builds/views cover logical records; native objects stay retained through
synchronous completion, excluding conflicting access. Mine executors retain
immutable table/device borrows and initialized private output; their CPU/GPU
table reads may overlap. V9 owns an initialized texture copy of logical bytes.
Partial builds and failed Blake/probe completion close affected owners. Failed
mine completion closes executor/output; read-only tables remain initialized.
Pre-submit rejection preserves usable input.'
if not ($original | str contains $before) { error make {msg: 'original contract differs'} }
let proposed = ($original | str replace $before $after)
let clause = 'CPU and GPU access must address the same physical pages.'
if not ($proposed | str contains $clause) { error make {msg: 'physical clause differs'} }
let dest = ($root | path join proposed README.md)
$proposed | save --force $dest
let run = (^git diff --no-index -- $path $dest | complete)
$run.stdout | save --force ($root | path join proposed specs.diff)
{command: ['git' 'diff' '--no-index' '--' $path $dest], expected_diff_exit: 1, actual_exit: $run.exit_code, stderr: $run.stderr, base: '8dcb33888868d74ddfda3eeeb9bc90e58677b394', original_sha256: ($original | hash sha256), proposed_sha256: ($proposed | hash sha256), diff_sha256: ($run.stdout | hash sha256), original_bytes: ($original | str length --utf-8-bytes), proposed_bytes: ($proposed | str length --utf-8-bytes), physical_clause_unchanged: true, source_file_modified: false} | to json | save --force ($root | path join proposed verification.json)
print ($run.stdout)
