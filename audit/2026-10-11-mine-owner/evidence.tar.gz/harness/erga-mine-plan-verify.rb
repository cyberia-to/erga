require 'json'
require 'digest'
require 'open3'
require 'time'

root = '/tmp/erga-mine-owner-plan-v1'
inputs = JSON.parse(File.read(File.join(root, 'review-inputs.json')))
brief = File.binread(File.join(root, 'brief.txt'))
freeze = JSON.parse(File.read(File.join(root, 'freeze.json')))
abort 'brief hash differs' unless Digest::SHA256.hexdigest(brief) == freeze['brief_sha256']
abort 'index differs' unless Digest::SHA256.file(File.join(root, 'review-inputs.json')).hexdigest == freeze['inventory_sha256']
cursor = 0
inputs.each_with_index do |row, i|
  marker = "===== INPUT #{i + 1}: #{row['name']} =====\n".b
  start = brief.index(marker, cursor) or abort "missing section #{i + 1}"
  body_start = brief.index("CONTENT-BEGIN\n".b, start) + "CONTENT-BEGIN\n".bytesize
  content = brief.byteslice(body_start, row['packed_bytes'])
  cursor = body_start + row['packed_bytes']
  ending = "\nCONTENT-END\n===== END INPUT #{i + 1} =====\n".b
  abort "ending differs #{i + 1}" unless brief.byteslice(cursor, ending.bytesize) == ending
  cursor += ending.bytesize
  original = File.binread(row['path'])
  abort "original differs #{row['name']}" unless Digest::SHA256.hexdigest(original) == row['sha256']
  abort "packed differs #{row['name']}" unless Digest::SHA256.hexdigest(content) == row['packed_sha256']
  if row['encoding'] == 'lossless compact JSON'
    abort "JSON changed #{row['name']}" unless JSON.parse(original) == JSON.parse(content)
  else
    abort "non-JSON changed #{row['name']}" unless original == content
  end
  if (git = row['git'])
    committed, status = Open3.capture2('git', '-C', git['repo'], 'show', "#{git['revision']}:#{git['path']}")
    abort "Git changed #{row['name']}" unless status.success? && committed.b == original
  end
end
abort 'unparsed suffix' unless brief.byteslice(cursor..).empty?
JSON.parse(File.read(File.join(root, 'source-manifest-references.json'))).each do |row|
  abort 'archive index differs' unless Digest::SHA256.file(row['path']).hexdigest == row['sha256']
  abort 'archive count differs' unless JSON.parse(File.read(row['path'])).length == row['files']
end
output, status = Open3.capture2('ruby', '/tmp/erga-mine-inventory.rb')
abort 'archive/baseline validation failed' unless status.success?
baseline = JSON.parse(output)
oracle = JSON.parse(File.read(File.join(root, 'oracle/vectors.json')))
abort 'oracle cases mismatch' unless oracle['vectors'].length == 360 && oracle['individual'].length == 18
abort 'published KAT differs' unless oracle['published_row'] == '77065d25b622a8251094d869edf6b4e9ba0708a8db1f239cb68e4eeb45851621'
abort 'texture y1 absent' unless oracle['texture_indices_nonce0_rows16384'].any? { |i| i >= 8192 && i < 16384 }
abort 'empty XOR differs' unless oracle['vectors'].select { |v| v['count'] == 0 }.all? { |v| v['xor'] == '0' * 64 }
oracle_record = JSON.parse(File.read(File.join(root, 'oracle/execution.json')))
abort 'Go failed' unless oracle_record['exit_code'] == 0
%w[source manifest lock stdout stderr].each do |what|
  file = {'source'=>'main.go','manifest'=>'go.mod','lock'=>'go.sum','stdout'=>'vectors.json','stderr'=>'stderr.txt'}.fetch(what)
  abort "Go #{what} hash differs" unless Digest::SHA256.file(File.join(root,'oracle',file)).hexdigest == oracle_record[what+'_sha256']
end
JSON.parse(File.read(File.join(root,'primary/review-excerpts.json'))).each do |r|
  original = File.binread(r['source'])
  abort 'primary original differs' unless Digest::SHA256.hexdigest(original) == r['source_sha256']
  abort 'primary excerpt differs' unless Digest::SHA256.file(r['path']).hexdigest == r['sha256']
  excerpt = File.binread(r['path'])
  r['ranges'].each { |a,z| abort 'primary range differs' unless excerpt.include?(original.lines[(a-1)..(z-1)].join) }
end
abort 'upstream Go cache differs' unless File.binread('/tmp/erga-rtable-owner-plan-v1/primary/go-blake2b.go') == File.binread('/Users/master/go/pkg/mod/golang.org/x/crypto@v0.48.0/blake2b/blake2b.go')
original_spec=File.binread(File.join(root,'source/erga/specs/README.md'))
proposed_spec=File.binread(File.join(root,'proposed/README.md'))
clause='CPU and GPU access must address the same physical pages.'
abort 'physical clause differs' unless original_spec.scan(clause).length == 1 && proposed_spec.scan(clause).length == 1
old_para=original_spec[/Blake batches.*?(?=\n\n## 6\.)/m]
new_para=proposed_spec[/Blake batches.*?(?=\n\n## 6\.)/m]
abort 'spec diff wider than paragraph' unless original_spec.sub(old_para,new_para)==proposed_spec
spec_receipt=JSON.parse(File.read(File.join(root,'proposed/verification.json')))
abort 'spec receipt differs' unless spec_receipt['original_sha256']==Digest::SHA256.hexdigest(original_spec) && spec_receipt['proposed_sha256']==Digest::SHA256.hexdigest(proposed_spec) && spec_receipt['actual_exit']==1
owned = '/Users/master/cyber/erga-unimem-mine-owner'
_, status = Open3.capture2('git', '-C', owned, 'diff', '--exit-code')
abort 'production modified' unless status.success?
_, status = Open3.capture2('git', '-C', owned, 'diff', '--check')
abort 'diff check failed' unless status.success?
result = {verified: Time.now.utc.iso8601, inputs: inputs.length, complete_git_bodies: inputs.count { |r| r['git'] }, compacted_json: inputs.count { |r| r['encoding'] == 'lossless compact JSON' }, nonjson_byte_exact: true, json_structurally_equal: true, committed_archive_paths: baseline['all_committed_paths_unchanged'], rust_corpus: baseline['rust_files'], baseline_commands: baseline['gate_records'], baseline_raw_streams: baseline['raw_streams'], original_lock_unchanged: true, oracle_published_vector_matches: true, oracle_batches: 360, oracle_individual: 18, texture_second_row_selected: true, primary_excerpts_verified: true, oracle_source_equals_pinned_upstream: true, production_unmodified: true, exact_proposed_spec_verified: true, physical_clause_unchanged: true, brief_bytes: brief.bytesize, brief_sha256: Digest::SHA256.hexdigest(brief), task_docs: inputs.first(2).map { |r| r.slice('name', 'sha256', 'bytes') }, reviewer_invoked: false}
File.write(File.join(root, 'verification.json'), JSON.pretty_generate(result) + "\n")
puts JSON.pretty_generate(result)
