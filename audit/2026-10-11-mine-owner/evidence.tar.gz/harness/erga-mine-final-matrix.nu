def main [] {
 let gates = [
  ["04-final-debug", "debug", ["test", "-p", "mine-bench", "-p", "rtable-bench", "--locked", "--offline"]],
  ["05-release", "debug", ["test", "-p", "mine-bench", "-p", "rtable-bench", "--release", "--locked", "--offline"]],
  ["06-final-clippy", "debug", ["clippy", "-p", "mine-bench", "-p", "rtable-bench", "--all-targets", "--no-deps", "--locked", "--offline", "--", "-D", "warnings"]],
  ["07-strict-docs", "docs", ["doc", "-p", "mine-bench", "-p", "rtable-bench", "--no-deps", "--document-private-items", "--locked", "--offline"]],
  ["08-nightly-docs", "nightly", ["test", "-p", "mine-bench", "-p", "rtable-bench", "--doc", "--locked", "--offline"]],
  ["09-mine-verify4", "debug", ["run", "-p", "mine-bench", "--locked", "--offline", "--", "verify", "4"]],
  ["10-rtable-verify4", "debug", ["run", "-p", "rtable-bench", "--locked", "--offline", "--", "verify", "4"]],
  ["11-invalid-exponent", "debug", ["run", "-p", "mine-bench", "--locked", "--offline", "--", "verify", "33"]],
  ["12-invalid-duration", "debug", ["run", "-p", "mine-bench", "--locked", "--offline", "--", "hybrid", "4", "NaN"]],
  ["13-owned-fmt", "rustfmt", ["--check", "--edition", "2021", "rs/mine-bench/src/lib.rs", "rs/mine-bench/src/main.rs", "rs/mine-bench/tests/owner.rs", "rs/mine-bench/tests/vectors.rs", "rs/rtable-bench/src/table.rs"]],
  ["14-workspace-check", "debug", ["check", "--workspace", "--all-targets", "--locked", "--offline"]],
  ["15-workspace-tests", "debug", ["test", "--workspace", "--locked", "--offline"]],
  ["16-workspace-build", "bootstrap", ["build", "--workspace", "--release", "--locked", "--offline"]],
  ["17-workspace-clippy", "debug", ["clippy", "--workspace", "--all-targets", "--no-deps", "--locked", "--offline", "--", "-D", "warnings"]],
  ["18-workspace-fmt", "debug", ["fmt", "--all", "--", "--check"]],
  ["19-miner-tests", "debug", ["test", "-p", "erga-miner", "--locked", "--offline"]],
  ["20-miner-difftest", "debug", ["run", "-p", "erga-miner", "--locked", "--offline", "--", "difftest"]]
 ]
 for gate in $gates { ^nu /tmp/erga-mine-execution-gate.nu ($gate | get 0) ($gate | get 1) (($gate | get 2) | to json --raw) }
}
