let root = '/tmp/erga-mine-owner-plan-v1'
let bin = '/Users/master/.rustup/toolchains/1.95.0-aarch64-apple-darwin/bin'
let rows = (['cargo' 'rustc' 'rustdoc' 'rustfmt' 'cargo-clippy' 'clippy-driver'] | each {|name|
 let path = ($bin | path join $name)
 let args = if $name == 'cargo-clippy' { ['--version'] } else if $name == 'rustc' { ['-Vv'] } else { ['--version'] }
 {name: $name, path: $path, sha256: (open --raw $path | hash sha256), args: $args, result: (with-env {PATH: ([$bin] | append $env.PATH), RUSTUP_TOOLCHAIN: '1.95.0', RUSTC: ($bin | path join rustc), RUSTDOC: ($bin | path join rustdoc)} {run-external $path ...$args | complete})}
})
{observed: (date now | format date '%+'), tools: $rows, host: (^uname -a | complete), resource: (^df -h /tmp | complete)} | to json | save ($root | path join toolchains.json)
print ($rows | select name result.exit_code)
