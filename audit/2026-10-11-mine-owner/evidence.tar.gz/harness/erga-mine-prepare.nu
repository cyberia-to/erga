let root = '/tmp/erga-mine-owner-plan-v1'
if ($root | path exists) { error make {msg: 'research root exists'} }
mkdir $root ($root | path join source) ($root | path join logs)
mut sources = []
for row in [
 {name: erga, repo: '/Users/master/cyber/erga-unimem-mine-owner', revision: '8dcb33888868d74ddfda3eeeb9bc90e58677b394'},
 {name: honeycrisp, repo: '/Users/master/cyber/honeycrisp-kadek-block-access', revision: '9cbd48070a136e24711896c930670fcff8a147fc'},
 {name: strata, repo: '/Users/master/cyber/strata', revision: '494df7a0973ae10a6cc1c2022e644d70449a29d6'}
] {
 let archive = ($root | path join $"($row.name).tar")
 let result = (^git -C $row.repo archive $row.revision -o $archive | complete)
 if $result.exit_code != 0 { error make {msg: $result.stderr} }
 let destination = ($root | path join source $row.name)
 mkdir $destination
 let result = (^tar -xf $archive -C $destination | complete)
 if $result.exit_code != 0 { error make {msg: $result.stderr} }
 let files = (glob ($destination | path join '**/*') | where {|p| ($p | path type) == file} | sort | each {|p| {path: ($p | path relative-to $destination), sha256: (open --raw $p | hash sha256)} })
 $files | to json | save ($root | path join $"($row.name)-source.json")
 $sources = ($sources | append ($row | insert archive_sha256 (open --raw $archive | hash sha256) | insert files ($files | length)))
}
$sources | to json | save ($root | path join origins.json)
cp ($root | path join source erga Cargo.lock) ($root | path join Cargo.lock.origin)
print $root
