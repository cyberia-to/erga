require 'json'
require 'digest'
require 'open3'
require 'time'
R='/tmp/erga-mine-owner-plan-v1'
W='/Users/master/cyber/erga-unimem-mine-owner'
def digest(bytes) = Digest::SHA256.hexdigest(bytes)
def run(*args)
  out,err,status=Open3.capture3(*args)
  raise "#{args.inspect}: #{err}" unless status.success?
  out.b
end
index=JSON.parse(File.binread(R+'/review-inputs.json'))
freeze=JSON.parse(File.binread(R+'/freeze.json'))
brief=File.binread(R+'/brief.txt')
raise 'brief changed' unless digest(brief)==freeze.fetch('brief_sha256')
raise 'index changed' unless digest(File.binread(R+'/review-inputs.json'))==freeze.fetch('inventory_sha256')
position=0
git_bodies=0
index.each_with_index do |input,i|
  marker="===== INPUT #{i+1}: #{input.fetch('name')} =====\n".b
  start=brief.index(marker,position) or raise "missing #{i+1}"
  header_end=brief.index("CONTENT-BEGIN\n".b,start) or raise 'missing content boundary'
  body_start=header_end+14
  body=brief.byteslice(body_start,input.fetch('packed_bytes'))
  suffix="\nCONTENT-END\n===== END INPUT #{i+1} =====\n".b
  position=body_start+body.bytesize
  raise 'suffix mismatch' unless brief.byteslice(position,suffix.bytesize)==suffix
  position+=suffix.bytesize
  original=File.binread(input.fetch('path'))
  raise "source identity #{i+1}" unless original.bytesize==input.fetch('bytes') && digest(original)==input.fetch('sha256')
  raise "packed identity #{i+1}" unless digest(body)==input.fetch('packed_sha256')
  if input.fetch('encoding')=='lossless compact JSON'
    raise 'changed JSON' unless JSON.parse(body)==JSON.parse(original)
  else
    raise 'changed exact body' unless body==original
  end
  if (g=input['git'])
    raise 'changed Git body' unless run('git','-C',g.fetch('repo'),'show',"#{g.fetch('revision')}:#{g.fetch('path')}")==original
    git_bodies+=1
  end
end
raise 'unparsed suffix' unless position==brief.bytesize
origins=JSON.parse(File.read(R+'/origins.json'))
archive_files=0
origins.each do |origin|
  name,repo,rev=origin.values_at('name','repo','revision')
  manifest=JSON.parse(File.read(R+"/#{name}-source.json"))
  tree=run('git','-C',repo,'ls-tree','-rz',rev).split("\0").map do |record|
    metadata,path=record.split("\t",2)
    mode,type,oid=metadata.split(' ')
    raise "nonblob #{path}" unless type=='blob'
    [path,oid]
  end.to_h
  raise "archive set #{name}" unless tree.keys.sort==manifest.map{|r|r.fetch('path')}.sort
  requests=manifest.map{|r|tree.fetch(r.fetch('path'))}.join("\n")+"\n"
  blobs=run('git','-C',repo,'cat-file','--batch',stdin_data: requests) if false
  raw,err,status=Open3.capture3('git','-C',repo,'cat-file','--batch',stdin_data:requests)
  raise err unless status.success?
  raw=raw.b; offset=0
  manifest.each do |entry|
    ending=raw.index("\n".b,offset) or raise 'batch header'
    oid,type,bytes=raw.byteslice(offset,ending-offset).split(' ')
    offset=ending+1
    body=raw.byteslice(offset,Integer(bytes));offset+=body.bytesize
    raise 'batch terminator' unless raw.byteslice(offset,1)=="\n".b
    offset+=1
    raise "Git archive #{entry['path']}" unless type=='blob' && oid==tree.fetch(entry['path']) && digest(body)==entry.fetch('sha256') && body==File.binread(R+"/source/#{name}/"+entry.fetch('path'))
    archive_files+=1
  end
  raise 'batch trailing bytes' unless offset==raw.bytesize
  raise 'tar changed' unless digest(File.binread(R+"/#{name}.tar"))==origin.fetch('archive_sha256')
end
streams=0
Dir.glob(R+'/logs/*.json').sort.each do |path|
  rec=JSON.parse(File.read(path));base=path.delete_suffix('.json')
  %w[stdout stderr].each do |kind|
    raise 'log changed' unless digest(File.binread(base+'.'+kind))==rec.fetch(kind+'_sha256')
    streams+=1
  end
  raise 'lock changed' unless rec.fetch('lock_before')==rec.fetch('lock_after') && rec.fetch('lock_after')==digest(File.binread(R+'/Cargo.lock.origin'))
end
JSON.parse(File.read(R+'/primary/review-excerpts.json')).each do |entry|
  original=File.binread(entry.fetch('source'))
  excerpt=File.binread(entry.fetch('path'))
  raise 'primary identity' unless digest(original)==entry.fetch('source_sha256') && digest(excerpt)==entry.fetch('sha256')
  entry.fetch('ranges').each{|first,last|raise 'excerpt differs' unless excerpt.include?(original.lines[(first-1)..(last-1)].join)}
end
before=run('git','-C',W,'show',freeze.fetch('source_base')+':specs/README.md')
after=File.binread(R+'/proposed/README.md')
clause='CPU and GPU access must address the same physical pages.'.b
raise 'physical clause changed' unless before.scan(clause).size==1 && after.scan(clause).size==1
para=/Blake batches.*?(?=\n\n## 6\.)/m
raise 'spec scope expanded' unless before.sub(before[para],after[para])==after
raise 'production edited' unless run('git','-C',W,'diff','--name-only').empty?
raise 'unexpected untracked file' unless run('git','-C',W,'ls-files','--others','--exclude-standard').lines.all?{|p|p.start_with?('.claude/tasks/mine-owner/')}
plan=File.binread(W+'/.claude/tasks/mine-owner/plan.md')
raise 'literal backslash n in plan' if plan.include?('\\n'.b)
%w[WorkerPanicked CounterOverflow InvalidInput].each{|word|raise 'worker priority absent' unless plan.include?(word)}
remotes=origins.map do |origin|
  reply=run('git','-C',origin.fetch('repo'),'ls-remote','origin','refs/heads/main')
  actual=reply.split.first
  raise 'origin drift' unless actual==origin.fetch('revision')
  {name:origin.fetch('name'),revision:actual}
end
receipt={checked_at:Time.now.utc.iso8601,command:['ruby',__FILE__],source_base:freeze.fetch('source_base'),input_count:index.length,git_bodies:git_bodies,archive_files:archive_files,raw_gate_streams:streams,brief_sha256:digest(brief),index_sha256:digest(File.binread(R+'/review-inputs.json')),task_docs:index.first(2).map{|r|r.slice('name','sha256','bytes')},exact_proposal_sha256:digest(after),proposal_diff_sha256:digest(File.binread(R+'/proposed/specs.diff')),physical_clause_unchanged:true,production_untouched:true,no_literal_newline_escape:true,current_origins:remotes,frozen_inputs_modified:false,reviewer_invoked:false}
File.write(R+'/resume-verification-20261011.json',JSON.pretty_generate(receipt)+"\n")
puts JSON.pretty_generate(receipt)
