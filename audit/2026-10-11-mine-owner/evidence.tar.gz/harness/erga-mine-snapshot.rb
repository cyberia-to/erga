require 'json';require 'digest';require 'fileutils'
r='/tmp/erga-mine-owner-execution';f=r+'/current-source.json';s=JSON.parse(File.read(f));h=Digest::SHA256.file(f).hexdigest;d=r+'/snapshots/'+h
unless File.exist?(d)
 FileUtils.mkdir_p(d);FileUtils.cp(f,d+'/source.json')
 s.fetch('files').each{|row|p=row.fetch('path');source=r+'/source/erga/'+p;raise 'changed source' unless Digest::SHA256.file(source).hexdigest==row.fetch('sha256');FileUtils.mkdir_p(File.dirname(d+'/'+p));FileUtils.cp(source,d+'/'+p)}
end
puts h
