require 'json'
require 'digest'
require 'fileutils'
require 'open3'
require 'time'
cap = '/tmp/erga-mine-owner-capsule-v1'
own = '/Users/master/cyber/erga-unimem-mine-owner'
aud = own + '/audit/2026-10-11-mine-owner'
FileUtils.cp(__FILE__, cap + '/harness/' + File.basename(__FILE__))
FileUtils.cp('/tmp/erga-mine-audit-outer.nu', cap + '/harness/erga-mine-audit-outer.nu')
rows = Dir.glob(cap + '/**/*', File::FNM_DOTMATCH).select { |p| File.file?(p) }.reject { |p| p == cap + '/inventory.json' }.sort.map do |p|
  {path: p.delete_prefix(cap + '/'), bytes: File.size(p), sha256: Digest::SHA256.file(p).hexdigest}
end
File.write(cap + '/inventory.json', JSON.pretty_generate(rows) + "\n")
FileUtils.cp(cap + '/inventory.json', aud + '/capsule-inventory.json')
_, err, status = Open3.capture3({'COPYFILE_DISABLE' => '1'}, 'tar', '-czf', aud + '/evidence.tar.gz', '-C', cap, '.')
raise err unless status.success?
archive_hash = Digest::SHA256.file(aud + '/evidence.tar.gz').hexdigest
File.write(aud + '/verify.nu', File.read('/tmp/erga-mine-audit-outer.nu').sub('ARCHIVE_SHA256', archive_hash))
argv = ['nu', aud + '/verify.nu', aud, '--source', own]
start = Time.now.utc.iso8601
out, err, status = Open3.capture3(*argv)
record = {command: argv, start: start, end: Time.now.utc.iso8601, exit_code: status.exitstatus, stdout: out, stderr: err, verification: status.success? ? JSON.parse(out) : nil, reran_native_work: false, archive_bytes: File.size(aud + '/evidence.tar.gz'), archive_sha256: archive_hash, verifier_sha256: Digest::SHA256.file(aud + '/verify.nu').hexdigest}
File.write(aud + '/replay.json', JSON.pretty_generate(record) + "\n")
raise err unless status.success?
files = Dir.glob(aud + '/**/*', File::FNM_DOTMATCH).select { |p| File.file?(p) }.reject { |p| p == aud + '/SHA256SUMS' }.sort
File.write(aud + '/SHA256SUMS', files.map { |p| Digest::SHA256.file(p).hexdigest + '  ' + p.delete_prefix(aud + '/') }.join("\n") + "\n")
puts JSON.pretty_generate(record)
