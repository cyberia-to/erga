def main [] {
 for gate in [
  ["21-parent-check", "parent", ["check", "--workspace", "--all-targets", "--locked", "--offline"]],
  ["22-parent-tests", "parent", ["test", "--workspace", "--locked", "--offline"]],
  ["23-parent-build", "parent-bootstrap", ["build", "--workspace", "--release", "--locked", "--offline"]],
  ["24-parent-clippy", "parent", ["clippy", "--workspace", "--all-targets", "--no-deps", "--locked", "--offline", "--", "-D", "warnings"]],
  ["25-parent-fmt", "parent", ["fmt", "--all", "--", "--check"]],
  ["26-candidate-all-deps-clippy", "stable", ["clippy", "--workspace", "--all-targets", "--locked", "--offline", "--", "-D", "warnings"]],
  ["27-parent-all-deps-clippy", "parent", ["clippy", "--workspace", "--all-targets", "--locked", "--offline", "--", "-D", "warnings"]],
  ["28-protocol-miner-tests", "stable", ["test", "-p", "autolykos", "-p", "erga-miner", "--locked", "--offline"]],
  ["29-cli-difftest", "stable", ["run", "-p", "erga-cli", "--bin", "erga", "--locked", "--offline", "--", "difftest"]],
  ["30-semver-mine", "semver", ["semver-checks", "-p", "mine-bench", "--release-type", "patch", "--baseline-root", "/tmp/erga-mine-owner-execution/legacy/erga"]],
  ["31-semver-rtable", "semver", ["semver-checks", "-p", "rtable-bench", "--release-type", "patch", "--baseline-root", "/tmp/erga-mine-owner-execution/legacy/erga"]]
 ] { ^nu /tmp/erga-mine-paired-gate.nu ($gate | get 0) ($gate | get 1) (($gate | get 2) | to json --raw) }
}
