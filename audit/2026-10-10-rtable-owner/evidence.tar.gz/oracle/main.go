package main

import (
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"os"

	"golang.org/x/crypto/blake2b"
)

func row(index, height uint32) [32]byte {
	var input [8]byte
	binary.LittleEndian.PutUint32(input[:4], index)
	binary.LittleEndian.PutUint32(input[4:], height)
	return blake2b.Sum256(input[:])
}

func selected(seed, i, n uint64) uint64 {
	x := seed + i*0x9e3779b97f4a7c15
	x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9
	x = (x ^ (x >> 27)) * 0x94d049bb133111eb
	return (x ^ (x >> 31)) % n
}

func main() {
	rows := []map[string]any{}
	for _, height := range []uint32{0, 0x07060504} {
		for _, index := range []uint32{0, 1, 2, 3, 64, 512, 0x03020100, 0xffffffff} {
			digest := row(index, height)
			rows = append(rows, map[string]any{"index": index, "height": height, "blake2b256": hex.EncodeToString(digest[:])})
		}
	}
	checksums := []map[string]any{}
	for _, n := range []uint64{1, 3, 65, 513} {
		for _, height := range []uint32{0, 0x07060504} {
			for _, count := range []uint32{0, 1, 2, 63, 64, 65, 257} {
				const seed uint64 = 0xa5a5a5a5deadbeef
				var sum uint64
				for i := uint64(0); i < uint64(count); i++ {
					digest := row(uint32(selected(seed, i, n)), height)
					sum ^= binary.LittleEndian.Uint64(digest[:8])
				}
				checksums = append(checksums, map[string]any{"rows": n, "height": height, "seed": seed, "reads": count, "checksum": sum})
			}
		}
	}
	encoder := json.NewEncoder(os.Stdout)
	encoder.SetIndent("", "  ")
	if err := encoder.Encode(map[string]any{"rows": rows, "checksums": checksums}); err != nil {
		panic(err)
	}
}
