module erga-rtable-owner-oracle

go 1.24.0

require golang.org/x/crypto v0.48.0
