def main [root: path = '.'] {
    let root = ($root | path expand)
    let inventory = (open ($root | path join inventory.json))
    for row in $inventory {
        let path = ($root | path join $row.path)
        if not ($path | path exists) or (open --raw $path | hash sha256) != $row.sha256 {
            error make {msg: $"payload differs: ($row.path)"}
        }
    }
    let actual = (glob ($root | path join '**/*') | where {|p| ($p | path type) == file} | each {|p| $p | path relative-to $root} | where {|p| $p != 'inventory.json'} | sort)
    if $actual != ($inventory | get path | sort) { error make {msg:'payload inventory is incomplete'} }
    for version in ['v1','v2'] {
        let freeze = (open ($root | path join $"source-freeze-($version).json"))
        for row in $freeze.overlay {
            if (open --raw ($root | path join $"source-($version)" $row.path) | hash sha256) != $row.sha256 {
                error make {msg: $"frozen source differs: ($version)/($row.path)"}
            }
        }
    }
    let records = (open ($root | path join commands.json))
    let lock = (open --raw ($root | path join Cargo.lock.origin) | hash sha256)
    for record in $records {
        let raw_record = (open ($root | path join logs $"($record.label).json"))
        if $record != $raw_record { error make {msg:'command index differs from raw record'} }
        for stream in ['stdout','stderr'] {
            if (open --raw ($root | path join logs $"($record.label).($stream)") | hash sha256) != ($record | get $"($stream)_sha256") {
                error make {msg: $"raw stream differs: ($record.label).($stream)"}
            }
        }
        if $record.lock_before != $lock or $record.lock_after != $lock { error make {msg:'execution lock changed'} }
    }
    let table = (open ($root | path join command-table.json))
    let restored = ($table.records | each {|record|
        let environment = ($table.environments | get $record.environment_index)
        $record | reject environment_index | insert environment $environment
    })
    if $restored != $records { error make {msg:'command dictionary lost data'} }
    if (open --raw ($root | path join commands.json) | hash sha256) != $table.original_commands_sha256 { error make {msg:'command file hash differs'} }
    let source_map = (open ($root | path join command-source-map.json))
    if ($source_map | columns | sort) != ($records | get label | sort) { error make {msg:'command source map differs'} }
    let plan_lock = (open --raw ($root | path join plan Cargo.lock.origin) | hash sha256)
    for path in (glob ($root | path join plan logs '*.json')) {
        let record = (open $path)
        for stream in ['stdout','stderr'] {
            if (open --raw ($root | path join plan logs $"($record.label).($stream)") | hash sha256) != ($record | get $"($stream)_sha256") {
                error make {msg:'PLAN raw stream differs'}
            }
        }
        if $record.lock_before != $plan_lock or $record.lock_after != $plan_lock { error make {msg:'PLAN lock changed'} }
    }
    let dictionary = (open ($root | path join review v2 raw-streams.json))
    for entry in ($dictionary.streams | transpose name value) {
        let bytes = ($entry.value.line_ids | each {|i| $dictionary.lines | get $i} | str join '')
        let original = ($root | path join logs ($entry.value.path | path basename))
        if ($bytes | hash sha256) != $entry.value.sha256 or $bytes != (open --raw $original) {
            error make {msg: $"review stream reconstruction differs: ($entry.name)"}
        }
    }
    let fmt = (open ($root | path join fmt-comparison.json))
    for row in ($fmt.files | transpose label value) {
        if (open --raw ($root | path join $row.value.path) | hash sha256) != $row.value.sha256 { error make {msg:'fmt comparison differs'} }
    }
    if (open --raw ($root | path join parent-workspace-fmt-unchanged.txt)) != (open --raw ($root | path join workspace-fmt-unchanged.txt)) { error make {msg:'unchanged formatter debt differs'} }
    let oracle = (open ($root | path join oracle execution.json))
    if (open --raw ($root | path join oracle vectors.json) | hash sha256) != $oracle.stdout_sha256 or (open --raw ($root | path join oracle stderr.txt) | hash sha256) != $oracle.stderr_sha256 { error make {msg:'oracle raw output differs'} }
    for pair in [[main.go source_sha256] [go.mod manifest_sha256] [go.sum lock_sha256]] {
        if (open --raw ($root | path join oracle $pair.0) | hash sha256) != ($oracle | get $pair.1) { error make {msg:'oracle source/manifest differs'} }
    }
    let code = (open ($root | path join review v2 pack.json))
    if (open --raw ($root | path join source-freeze-v2.json) | hash sha256) != $code.source_freeze_sha256 { error make {msg:'reviewed source freeze differs'} }
    {payloads:($inventory | length), commands:($records | length), raw_streams:(2 * ($records | length)), zero:($records | where exit_code == 0 | length), nonzero:($records | where exit_code != 0 | length), source_snapshots:2, paths_per_snapshot:10, reconstructed_review_streams:($dictionary.streams | columns | length), command_dictionary_lossless:true, all_payload_hashes_match:true, reran_native_work:false} | to json | print
}
