let root = '/tmp/erga-rtable-owner-execution-v1'
mut results = []
for tc in ['1.95.0' 'nightly-2025-11-26'] {
 let bin = $'/Users/master/.rustup/toolchains/($tc)-aarch64-apple-darwin/bin'
 for exe in ['cargo' 'rustc' 'rustdoc' 'rustfmt' 'clippy-driver'] {
  let path = ($bin | path join $exe)
  if ($path | path exists) {
   let result = (run-external $path '--version' | complete)
   $results = ($results | append {toolchain: $tc, path: $path, sha256: (open --raw $path | hash sha256), stdout: $result.stdout, stderr: $result.stderr, exit_code: $result.exit_code})
  }
 }
 let result = (run-external ($bin | path join rustc) '-vV' | complete)
 $results = ($results | append {toolchain: $tc, command: ($bin | path join rustc), args: ['-vV'], result: $result})
}
{date: (date now | format date '%+'), host: (^uname -a | complete), tools: $results, semver: (^cargo semver-checks --version | complete), resources: (^df -h /tmp | complete)} | to json | save ($root | path join toolchains.json)
