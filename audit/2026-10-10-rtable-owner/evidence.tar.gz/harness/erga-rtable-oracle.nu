let root = '/tmp/erga-rtable-owner-plan-v1'
let directory = ($root | path join oracle)
cd $directory
let environment = {GOWORK: 'off', GOTOOLCHAIN: 'local', GOPROXY: 'off', GOSUMDB: 'off', GOCACHE: ($root | path join go-cache), GOMAXPROCS: '2'}
let command = '/opt/homebrew/bin/go'
let args = ['run' '-mod=readonly' '.']
let start = (date now | format date '%+')
let result = (with-env $environment { run-external $command ...$args | complete })
$result.stdout | save ($directory | path join vectors.json)
$result.stderr | save ($directory | path join stderr.txt)
{command: $command, args: $args, environment: $environment, cwd: $directory, start: $start, end: (date now | format date '%+'), exit_code: $result.exit_code, tool_sha256: (open --raw $command | hash sha256), version: (^go version | complete), stdout_sha256: ($result.stdout | hash sha256), stderr_sha256: ($result.stderr | hash sha256), crypto_origin: (open /Users/master/go/pkg/mod/cache/download/golang.org/x/crypto/@v/v0.48.0.info), crypto_ziphash: (open --raw /Users/master/go/pkg/mod/cache/download/golang.org/x/crypto/@v/v0.48.0.ziphash), source_sha256: (open --raw main.go | hash sha256), manifest_sha256: (open --raw go.mod | hash sha256), lock_sha256: (open --raw go.sum | hash sha256)} | to json | save ($directory | path join execution.json)
if $result.exit_code != 0 { error make {msg: $result.stderr} }
let published = ($result.stdout | from json | get rows | where index == 50462976 and height == 117835012 | first | get blake2b256)
if $published != '77065d25b622a8251094d869edf6b4e9ba0708a8db1f239cb68e4eeb45851621' { error make {msg: 'published eight-byte vector mismatch'} }
{published_vector: $published, published_vector_matches: true, rows: ($result.stdout | from json | get rows | length), checksum_cases: ($result.stdout | from json | get checksums | length), no_erga_code_used: true} | to json | save ($directory | path join verification.json)
print $"independent Go oracle: exit ($result.exit_code)"
