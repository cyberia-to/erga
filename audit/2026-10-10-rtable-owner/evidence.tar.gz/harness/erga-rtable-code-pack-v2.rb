require 'json';require 'digest';require 'fileutils';require 'time'
V1='/tmp/erga-rtable-owner-code-v1';OUT='/tmp/erga-rtable-owner-code-v2';EXEC='/tmp/erga-rtable-owner-execution-v1'
FileUtils.mkdir_p(OUT)
def sha(s)=Digest::SHA256.hexdigest(s)
def read(p)=File.binread(p)
def input(name,path,revision)
 bytes=read(path);packed=path.end_with?('.json') ? JSON.generate(JSON.parse(bytes)).b : bytes
 {name:name,path:path,revision:revision,sha256:sha(bytes),bytes:bytes.bytesize,packed_sha256:sha(packed),packed_bytes:packed.bytesize,encoding:path.end_with?('.json') ? 'lossless compact JSON' : 'byte-exact',content:packed}
end
old=JSON.parse(read(V1+'/review-inputs.json'))
# Intern complete lines; all information, ordering and final-newline state remain
# exact. This removes repeated Cargo compilation preambles/diagnostics only.
lines=[]; lookup={}; streams={}
old.select{|i|i['name'].start_with?('execution/logs/')}.each do |i|
 bytes=read(i['path']);raise 'raw drift' unless sha(bytes)==i['sha256']
 ids=bytes.lines.map{|line|lookup.fetch(line){id=lines.length;lines<<line;lookup[line]=id}}
 streams[i['name']]={path:i['path'],sha256:i['sha256'],bytes:bytes.bytesize,line_ids:ids}
end
File.write(OUT+'/raw-streams.json',JSON.pretty_generate({encoding:'For each stream, concatenate lines[line_ids[i]] in order, including each stored newline; byte-exact reconstruction, not a summary.',lines:lines,streams:streams})+"\n")
omit=%w[erga/Cargo.lock execution/tracked-source-v2.diff]
references=old.select{|i|omit.include?(i['name'])}.map{|i|i.merge('reason'=>i['name']=='erga/Cargo.lock' ? 'Exact unchanged lock; full byte-exact input in approved PLAN and CODE v1. All gate records verify identical lock, no candidate delta. Manifests/provider sources remain complete.' : 'Diff repeats original/candidate bodies already complete in this brief; full diff retained and pinned.')}
File.write(OUT+'/byte-references.json',JSON.pretty_generate({v1_brief_sha256:sha(read(V1+'/brief.txt')),references:references})+"\n")
inputs=old.reject{|i|i['name'].start_with?('execution/logs/') || omit.include?(i['name'])}.map do |i|
 bytes=read(i['path']);raise 'v1 input drift' unless sha(bytes)==i['sha256']
 input(i['name'],i['path'],i['revision']).merge(i['git'] ? {git:i['git']} : {}).merge(i['frozen_sha256'] ? {frozen_sha256:i['frozen_sha256']} : {})
end
inputs<<input('execution/raw-streams.json',OUT+'/raw-streams.json','lossless raw output dictionary; full direct streams retained CODEv1/logs')
inputs<<input('execution/byte-references.json',OUT+'/byte-references.json','unchanged lock and redundant diff reference; actual source remains complete')
instructions=read(V1+'/brief.txt').split("\n\n===== INPUT 1:",2).first
instructions.sub!('Entire unchanged Cargo.lock appears once.', 'The exact unchanged121KB Cargo.lock is hash-referenced to the complete approved PLAN/CODEv1 body; all manifests remain complete and every gate verifies that identical lock.')
instructions.sub!('Every non-format raw command stream including initial failures is present.', 'Every non-format raw command stream including initial failures is losslessly represented by an exact line dictionary with order/final-newline/hash. Repeated Cargo preambles/error lines appear once; direct complete raw streams remain in CODEv1/logs. The redundant tracked diff is hash-referenced because all original/candidate bodies are included in full. No changed/caller/provider/primary source body is omitted or excerpted.')
brief=instructions.b+inputs.each_with_index.map{|i,n|"\n\n===== INPUT #{n+1}: #{i[:name]} @ #{i[:revision]} [SHA256 #{i[:sha256]}#{i[:encoding]=='byte-exact' ? '' : "; packed #{i[:packed_sha256]}"}] =====\nCONTENT-BEGIN\n".b+i[:content]+"\nCONTENT-END\n===== END INPUT #{n+1} =====\n".b}.join
File.binwrite(OUT+'/brief.txt',brief)
File.write(OUT+'/review-inputs.json',JSON.pretty_generate(inputs.map{|i|i.reject{|k,_|k==:content}})+"\n")
meta={created:Time.now.utc.iso8601,inputs:inputs.length,git_bodies:inputs.count{|i|i[:git]},candidate_full_bodies:inputs.count{|i|i[:frozen_sha256]},compacted_json:inputs.count{|i|i[:encoding]=='lossless compact JSON'},raw_streams:streams.length,raw_original_bytes:streams.values.sum{|i|i[:bytes]},raw_dictionary_bytes:File.size(OUT+'/raw-streams.json'),brief_bytes:brief.bytesize,brief_sha256:sha(brief),index_sha256:sha(read(OUT+'/review-inputs.json')),source_freeze_sha256:sha(read(EXEC+'/source-freeze-v2.json')),builder_sha256:sha(read(__FILE__)),instructions_words:instructions.split.length,reviewer_invoked:false}
File.write(OUT+'/pack.json',JSON.pretty_generate(meta)+"\n");puts JSON.pretty_generate(meta)
