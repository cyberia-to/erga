require 'json';require 'digest';require 'open3'
def sha(s)=Digest::SHA256.hexdigest(s)
def read(p)=File.binread(p)
root='/tmp/erga-rtable-owner-code-v2'; v1='/tmp/erga-rtable-owner-code-v1'; ex='/tmp/erga-rtable-owner-execution-v1'
counts={}
[v1,root].each do |base|
 index=JSON.parse(read(base+'/review-inputs.json'));brief=read(base+'/brief.txt');pack=JSON.parse(read(base+'/pack.json'))
 raise 'brief hash' unless sha(brief)==pack['brief_sha256'] && sha(read(base+'/review-inputs.json'))==pack['index_sha256']
 cursor=0;gitcount=0;jsoncount=0
 index.each_with_index do |item,n|
  actual=read(item['path']);raise "raw #{item['name']}" unless sha(actual)==item['sha256'] && actual.bytesize==item['bytes']
  position=brief.index("===== INPUT #{n+1}:",cursor);raise 'header missing' unless position
  start=brief.index("CONTENT-BEGIN\n",position)+"CONTENT-BEGIN\n".bytesize
  packed=brief.byteslice(start,item['packed_bytes']);raise "packed #{item['name']}" unless sha(packed)==item['packed_sha256']
  finish=start+item['packed_bytes'];raise 'section end' unless brief.byteslice(finish,14)=="\nCONTENT-END\n="
  cursor=finish
  if item['encoding']=='byte-exact'
   raise 'source bytes' unless packed==actual
  else
   raise 'JSON structure' unless JSON.parse(packed)==JSON.parse(actual);jsoncount+=1
  end
  if g=item['git']
   committed,s=Open3.capture2('git','-C',g['repo'],'show',"#{g['revision']}:#{g['path']}")
   raise 'Git body' unless s.success? && committed.b==actual;gitcount+=1
  end
 end
 counts[File.basename(base)]={sections:index.length,git:gitcount,lossless_json:jsoncount,sha256:sha(brief)}
end
refs=JSON.parse(read(root+'/byte-references.json'))
raise 'v1 reference' unless refs['v1_brief_sha256']==sha(read(v1+'/brief.txt'))
refs['references'].each{|i|raise 'reference hash' unless sha(read(i['path']))==i['sha256']}
dict=JSON.parse(read(root+'/raw-streams.json'))
dict['streams'].each do |name,s|
 raw=s['line_ids'].map{|i|dict['lines'].fetch(i)}.join.b
 raise "reconstruction #{name}" unless raw==read(s['path']) && sha(raw)==s['sha256'] && raw.bytesize==s['bytes']
end
# Compare all v1 logical inputs with v2 or its byte-exact raw/reference representations.
v2=JSON.parse(read(root+'/review-inputs.json')).to_h{|i|[i['name'],i]}
JSON.parse(read(v1+'/review-inputs.json')).each do |i|
 other=v2[i['name']] || dict['streams'][i['name']] || refs['references'].find{|j|j['name']==i['name']}
 raise "missing #{i['name']}" unless other && other['sha256']==i['sha256']
end
records=JSON.parse(read(ex+'/commands.json'));table=JSON.parse(read(ex+'/command-table.json'))
reconstructed=table['records'].map{|i|i.reject{|k,_|k=='environment_index'}.merge('environment'=>table['environments'].fetch(i['environment_index']))}
raise 'command records' unless reconstructed==records && table['original_commands_sha256']==sha(read(ex+'/commands.json'))
freeze=JSON.parse(read(ex+'/source-freeze-v2.json'))
freeze['overlay'].each do |i|
 ["/Users/master/cyber/erga-unimem-rtable-owner/#{i['path']}","#{ex}/source/erga/#{i['path']}"].each{|p|raise 'freeze' unless sha(read(p))==i['sha256']}
end
result={status:'verified',packs:counts,complete_v1_inputs_represented:true,byte_references:refs['references'].length,raw_streams_reconstructed:dict['streams'].length,command_records_reconstructed:records.length,source_overlay_unchanged:freeze['overlay'].length}
File.write(root+'/verification.json',JSON.pretty_generate(result)+"\n");puts JSON.pretty_generate(result)
