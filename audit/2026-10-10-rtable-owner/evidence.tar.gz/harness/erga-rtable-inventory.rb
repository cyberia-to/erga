require 'json'
require 'digest'
require 'open3'

root = '/tmp/erga-rtable-owner-plan-v1'
repo = '/Users/master/cyber/erga-unimem-rtable-owner'
revision = '14b40d667b7fa927f62f46423cd8096f01cf704f'
paths, status = Open3.capture2('git', '-C', repo, 'ls-tree', '-r', '--name-only', revision)
abort 'git inventory failed' unless status.success?
patterns = {
  'rtable_surface' => /\b(?:RTable|Probe|lcg_index|read_u64|write_u64)\b|rtable[_-]bench/,
  'raw_or_async' => /\.(?:block|buffer|n|as_bytes|as_bytes_mut|wrap|buffer_wrap|submit|wait)\b|\b(?:spawn|spawn_scoped|thread::scope|forget|unsafe\s+impl|async)\b/,
}
inventory = paths.lines.map(&:strip).grep(/\.rs\z/).map do |path|
  bytes, read_status = Open3.capture2('git', '-C', repo, 'show', "#{revision}:#{path}")
  abort path unless read_status.success?
  local = File.binread(File.join(root, 'source/erga', path))
  abort "archive differs #{path}" unless bytes.b == local
  hits = patterns.transform_values { |pattern| bytes.lines.each_with_index.filter_map { |line, i| {'line' => i + 1, 'text' => line.chomp} if pattern.match?(line) } }
  {'path' => path, 'sha256' => Digest::SHA256.hexdigest(bytes), 'lines' => bytes.lines.length, 'matches' => hits}
end
File.write(File.join(root, 'caller-inventory.json'), JSON.pretty_generate({revision: revision, command: ['git ls-tree -r --name-only <revision>', 'git show <revision>:<path>'], patterns: patterns.transform_values(&:source), files: inventory}) + "\n")
source_rows = JSON.parse(File.read(File.join(root, 'origins.json')))
source_rows.each do |row|
  actual = JSON.parse(File.read(File.join(root, "#{row['name']}-source.json")))
  actual.each do |file|
    abort "source changed #{row['name']}/#{file['path']}" unless Digest::SHA256.file(File.join(root, 'source', row['name'], file['path'])).hexdigest == file['sha256']
  end
end
metadata = JSON.parse(File.read(File.join(root, 'logs/metadata-origin.stdout')))
local_packages = metadata['packages'].select { |p| p['source'].nil? }.map { |p| p.slice('name', 'version', 'manifest_path', 'dependencies') }
abort 'working tree package in closure' unless local_packages.all? { |p| File.realpath(p['manifest_path']).start_with?(File.realpath(File.join(root, 'source')) + '/') }
File.write(File.join(root, 'resolved-local-packages.json'), JSON.pretty_generate(local_packages) + "\n")
lock = Digest::SHA256.file(File.join(root, 'Cargo.lock.origin')).hexdigest
records = Dir.glob(File.join(root, 'logs/*.json')).sort.map { |path| JSON.parse(File.read(path)) }
records.each do |r|
  abort 'lock mutated' unless r['lock_before'] == lock && r['lock_after'] == lock
  %w[stdout stderr].each do |stream|
    abort 'stream differs' unless Digest::SHA256.file(File.join(root, 'logs', "#{r['label']}.#{stream}")).hexdigest == r["#{stream}_sha256"]
  end
end
receipt = {revision: revision, all_committed_paths_unchanged: source_rows.sum { |r| r['files'] }, rust_files: inventory.length, rtable_match_files: inventory.select { |r| !r['matches']['rtable_surface'].empty? }.map { |r| r['path'] }, local_packages: local_packages.length, gate_records: records.length, raw_streams: records.length * 2, original_lock_unchanged: true, lock_sha256: lock, zero_match_files_explicit: true, no_legacy_native_execution: true}
File.write(File.join(root, 'baseline-verification.json'), JSON.pretty_generate(receipt) + "\n")
puts JSON.pretty_generate(receipt)
