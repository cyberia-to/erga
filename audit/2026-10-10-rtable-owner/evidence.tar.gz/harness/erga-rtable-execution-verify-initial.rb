require 'json'; require 'digest'; require 'open3'; require 'set'
r='/tmp/erga-rtable-owner-execution-v1'; owned='/Users/master/cyber/erga-unimem-rtable-owner'
sha=->(p){Digest::SHA256.file(p).hexdigest}
freeze=JSON.parse(File.read("#{r}/source-freeze-v2.json"))
overlay=freeze.fetch('overlay').to_h{|i|[i.fetch('path'),i]}
origins=JSON.parse(File.read("#{r}/origins.json"))
verified=0
origins.each do |o|
 paths,s=Open3.capture2('git','-C',o['repo'],'ls-tree','-r','--name-only',o['revision']);raise unless s.success?
 expected_paths=paths.lines.map(&:chomp)
 expected_paths.each do |path|
  original,s=Open3.capture2('git','-C',o['repo'],'show',"#{o['revision']}:#{path}");raise unless s.success?
  %w[parent source].each do |dir|
   actual=File.binread("#{r}/#{dir}/#{o['name']}/#{path}")
   expected=dir=='source' && o['name']=='erga' && overlay[path] ? File.binread("#{owned}/#{path}") : original.b
   raise "archive mismatch #{dir}/#{o['name']}/#{path}" unless actual==expected
  end
  verified+=1
 end
 actual_paths=Dir.glob("#{r}/source/#{o['name']}/**/*",File::FNM_DOTMATCH).select{|p|File.file?(p)}.map{|p|p.delete_prefix("#{r}/source/#{o['name']}/")}
 allowed=expected_paths + (o['name']=='erga' ? overlay.keys : [])
 raise "extra paths #{o['name']}: #{actual_paths-allowed}" unless (actual_paths-allowed).empty?
end
freeze['overlay'].each do |i|
 ["#{owned}/#{i['path']}","#{r}/source/erga/#{i['path']}"].each{|p|raise "freeze #{p}" unless sha.call(p)==i['sha256']}
 raise 'line cap' if i['path'].end_with?('.rs') && i['lines']>500
end
records=Dir.glob("#{r}/logs/*.json").sort.map{|p|JSON.parse(File.read(p))}
records.each do |c|
 %w[stdout stderr].each{|stream| raise "stream #{c['label']}.#{stream}" unless sha.call("#{r}/logs/#{c['label']}.#{stream}")==c["#{stream}_sha256"]}
 raise "lock changed #{c['label']}" unless c['lock_before']==c['lock_after'] && c['lock_before']==sha.call("#{r}/Cargo.lock.origin")
end
%w[research.md plan.md].each{|f|raise "PLAN changed #{f}" unless File.binread("#{owned}/.claude/tasks/rtable-owner/#{f}")==File.binread("#{r}/frozen-plan/#{f}")}
legacy=JSON.parse(File.read("#{r}/legacy-provenance.json"))['legacy']
legacy.each do |name,rev|
 next unless %w[erga honeycrisp strata].include?(name)
 repo=origins.find{|o|o['name']==name}.fetch('repo')
 paths,s=Open3.capture2('git','-C',repo,'ls-tree','-r','--name-only',rev);raise unless s.success?
 paths.lines.map(&:chomp).each do |p|
  original,s=Open3.capture2('git','-C',repo,'show',"#{rev}:#{p}");raise unless s.success?
  if name=='erga' && p=='Cargo.lock'
   original=original.sub(/(name = "unimem"\nversion = "0\.2\.0"\ndependencies = \[\n) "libc",\n/,'\1')
  end
  raise "legacy mismatch #{name}/#{p}" unless File.binread("#{r}/legacy/#{name}/#{p}")==original.b
 end
end
j=JSON.parse(File.read('/tmp/erga-rtable-owner-plan-v1/oracle/vectors.json'))
s=File.read("#{owned}/rs/rtable-bench/tests/support/vectors.rs")
rows=s.split('pub const CHECKSUMS')[0].scan(/\(\s*(\d+),\s*(\d+),\s*\[([^\]]+)\]/m).map{|h,i,b|{'height'=>h.to_i,'index'=>i.to_i,'blake2b256'=>b.scan(/0x([0-9a-f]{2})/).flatten.join}}
checksums=s.split('pub const CHECKSUMS')[1].scan(/\(\s*(\d+),\s*(\d+),\s*(\d+),\s*0x([0-9a-f]+)\s*\)/m).map{|n,h,c,v|{'rows'=>n.to_i,'height'=>h.to_i,'reads'=>c.to_i,'checksum'=>v.to_i(16),'seed'=>0xa5a5a5a5deadbeef}}
raise 'row vectors' unless rows==j['rows']
raise 'checksum vectors' unless checksums==j['checksums']
result={status:'verified',base:origins,committed_paths:verified,explicit_overlay:overlay.length,commands:records.length,raw_streams:records.length*2,command_exits:records.group_by{|c|c['exit_code']}.transform_values(&:length),source_freeze_sha256:sha.call("#{r}/source-freeze-v2.json"),oracle_rows:rows.length,oracle_checksums:checksums.length,limitations:'No native OS/GPU fault or cross-device injection; no global provider/PA/phase/rung/release closure.'}
File.write("#{r}/verification.json",JSON.pretty_generate(result)+"\n")
puts JSON.pretty_generate(result)
