require 'json';require 'digest';require 'open3';require 'time';require 'fileutils'
PLAN='/tmp/erga-rtable-owner-plan-v1'; EXEC='/tmp/erga-rtable-owner-execution-v1'; OUT='/tmp/erga-rtable-owner-code-v1'; OWN='/Users/master/cyber/erga-unimem-rtable-owner'
FileUtils.mkdir_p(OUT)
def sha(s)=Digest::SHA256.hexdigest(s)
def read(p)=File.binread(p)
def row(name,path,revision,**extra)
 bytes=read(path);packed=path.end_with?('.json') ? JSON.generate(JSON.parse(bytes)).b : bytes
 {name:name,path:path,revision:revision,sha256:sha(bytes),bytes:bytes.bytesize,packed_sha256:sha(packed),packed_bytes:packed.bytesize,encoding:path.end_with?('.json') ? 'lossless compact JSON' : 'byte-exact',content:packed}.merge(extra)
end
inputs=JSON.parse(read(PLAN+'/review-inputs.json')).map do |item|
 raise 'PLAN input drift' unless sha(read(item['path']))==item['sha256']
 row(item['name'],item['path'],item['revision'],**(item['git'] ? {git:item['git']} : {}))
end
freeze=JSON.parse(read(EXEC+'/source-freeze-v2.json'))
freeze['overlay'].each do |item|
 path=OWN+'/'+item['path'];raise 'source changed' unless sha(read(path))==item['sha256']
 inputs << row('candidate/erga/'+item['path'],path,'frozen local overlay on '+freeze['revision'],frozen_sha256:item['sha256'])
end
inputs << row('candidate/erga/.claude/tasks/rtable-owner/execution.md',OWN+'/.claude/tasks/rtable-owner/execution.md','execution disposition; source freeze unchanged')
%w[README.md frozen-plan/review.txt source-freeze-v1.json source-freeze-v2.json tracked-source-v2.diff command-table.json command-source-map.json verification.json fmt-comparison.json diagnostic-comparison.json legacy-provenance.json toolchains.json resource-observation.json format-correction.json].each do |path|
 inputs << row('execution/'+path,EXEC+'/'+path,'actual exact-source execution records,2026-10-10')
end
Dir[EXEC+'/logs/*.{stdout,stderr}'].sort.each do |path|
 next if %w[parent-workspace-fmt.stdout workspace-fmt.stdout].include?(File.basename(path))
 inputs << row('execution/logs/'+File.basename(path),path,'complete raw output; records/source map pin command and overlay')
end
%w[/tmp/erga-rtable-execution-gate.nu /tmp/erga-rtable-execution-verify.rb /tmp/erga-rtable-execution-summary.rb /tmp/erga-rtable-gates.nu].each{|path|inputs<<row('execution/harness/'+File.basename(path),path,'exact execution/verification helper')}
instructions=<<~TEXT
Fresh independent CODE review. Return APPROVE or REQUEST CHANGES first; actual blockers separate from optional notes. No tools: complete original/candidate source bodies, approved frozen PLAN, primary evidence and actual execution follow. Review implementation independently rather than treating prior PLAN approval or green scoped tests as proof. This is a narrow RTable/probe/sole CLI ownership unit discovered from HoneyPR14/ErgaPR1 while advancing Kadek foundation row6. It does not close mine/Erga/rung/Image, physical/pinning policy or provider-wide soundness.

Exact parent Erga14b40d667b7fa927f62f46423cd8096f01cf704f, Honey9cbd48070a136e24711896c930670fcff8a147fc, Strata494df7a0973ae10a6cc1c2022e644d70449a29d6. Candidate ten-path overlay: no manifest/lock/shader/provider/mine change; largest Rust242lines. Original PLAN input sections below retain their historical labels; candidate sections are explicitly labeled local overlay. All changed/new Rust, private tests, integration/literal fixtures, spec and original callers are full bodies. Original source selection includes all39-file caller/zero-match inventory, complete mine lib/main/texture FFI and shaders, exact provider/FFI/native primary and Rust scoped-thread source. Each non-JSON section is byte-exact; JSON compacting preserves structure. Entire unchanged Cargo.lock appears once. Opaque846-path archive manifests remain hash-referenced with independent verifier; all selected actual code is included. Full workspace fmt streams remain hashed locally, with independently verified154 unchanged sections after only path normalization/allowlist exclusions; they are not repeated in the review brief. Every non-format raw command stream including initial failures is present.

Inspect complete initialization before any reference/import, actual-versus-logical extent, 1..=2^32 row domain and safe u32 row encoding, checked page/isize/native-device limit, current whole RW VM leaf and ulong alignment, retained imported Buffer-before-Block lifetime, device identity and no native alias. Probe's accumulator is initialized/owned/private with8bytes/shared/u32alignment checks. !Send/!Sync is inherited; no unsafe trait impl. CPU build lends only disjoint logical chunks to scoped workers, uses fallible spawn and entire-scope catch_unwind, joins all workers before return and restores access only on total success. AssertUnwindSafe does not authorize recovering partial data. Private simulated spawn-after-one and panic tests exercise that path; callbacks are not public. Check unknown lifetime/forget/async routes, worker error races and field-order cleanup.

GPU exact count/nonuniform grid matches unchanged Metal shader uint index and24-byte manually initialized params, including pad. Count0 checks availability and identity but does not submit. Positive path validates geometry/caps/pipeline/device width; fallible command/encoder allocation precedes state closure. Command and encoder retain resources through adjacent submit/wait; no allocation/fallible/untrusted gap. Only native completed+None reopens both owners and publishes copied checksum; all other completion outcomes permanently close access. Pre-submit rejection preserves usable table. Source proof is required for native alias, lifetime and drop order, not merely assertions or tests.

Scoped debug/release each9 private+2 integration+10 stable doctests pass; actual nightly10 expected-code tests pass. Compiler is pinned rustup1.95/LLVM22.1.2; nightly2025-11-26 uses real1.93nightly rustc/rustdoc. Selected all-target check/strictClippy/docs and finalfmt pass. Initial formatter accidentally used edition2024; retained owned check failed1, correction only import ordering/assert formatting, finaldebug/Clippy repeated. v1 snapshot/source map preserves which commands used each version. No semantic source correction and no edits after v2freeze.

Native tables1,3,65,513, two heights and workers1/2/3 compare full logical row bytes,56 independent Go checksum literals,16 row-function literals including independent published eight-byte BoringSSL record. High-index function literals do not claim huge native table execution. Probe counts0/1/2/63/64/65/257 and reuse; real poisoned actualextent and padding canaries; threadsusizeMAX on only3rows. Zero-unbuilt checks prevent a zero oracle masquerading as a built relation; one-read built cases are nonzero. Worker panic/spawn and completion status/error cases are explicitly simulated; no injected OS/GPU fault, fake handles or real cross-device claim. One-device identity/drop order remain source evidence.

29 commands/58 complete retained rawstreams:13exit0,16nonzero. Two invalid CLI argument exits1 are expected rejection, not product pass. CLI verify4 passes. Separate productionminer7 tests/check and512-nonce GPU/CPU difftest pass; miner does not depend on RTable. Paired workspace check/test/bootstraprelease/strict+warningsClippy parent shows old RTable3E0133+1E0596, candidate exposes8 new mine lib private/missing-field errors. Other mine lifetime/main/mutability errors and old chime are masked, not fixed. Both workspacefmt exit1 with unchanged debt. Patchsemver against tagv0.30.0 plus historical Honey7b148906 and reviewed one-line diagnostic lock normalization exits100 with9major lint classes. No historical raw owner executed. Explicit API catalog supplements tool findings, especially Result, arguments and ownership changes. The future mine unit requires a new reviewed exactactualextent import boundary; current logical bytes do not supply it.

Native preflight is deliberately duplicated from existing Blake, owned by Erga bench maintenance; no generic API extraction now. Manifest unuseddeps stay frozen. Compact spec retains same-physical-pages requirement unchanged; observations remain audit/task. Named huge epochbuildbench, packaging and benchmark/default/mining/network loops were not run. Root owns fresh CODE review, audit, decision label and merge; no release or full-phase claim. Find actionable safety/correctness/state/test/evidence defects in this scope, without demanding unrelated kernel/provider/mine/physical-policy repair or cosmetic churn.
TEXT
raise 'instructions too long' if instructions.split.length>1500
raise 'duplicate input' unless inputs.map{|i|i[:name]}.uniq.length==inputs.length
brief=instructions.b+inputs.each_with_index.map do |i,n|
 "\n\n===== INPUT #{n+1}: #{i[:name]} =====\nREVISION: #{i[:revision]}\nORIGINAL-SHA256: #{i[:sha256]}\nENCODING: #{i[:encoding]}\nPACKED-SHA256: #{i[:packed_sha256]}\nPATH: #{i[:path]}\nCONTENT-BEGIN\n".b+i[:content]+"\nCONTENT-END\n===== END INPUT #{n+1} =====\n".b
end.join
File.binwrite(OUT+'/brief.txt',brief)
File.write(OUT+'/review-inputs.json',JSON.pretty_generate(inputs.map{|i|i.reject{|k,_|k==:content}})+"\n")
meta={created:Time.now.utc.iso8601,inputs:inputs.length,git_bodies:inputs.count{|i|i[:git]},candidate_full_bodies:freeze['overlay'].length,compacted_json:inputs.count{|i|i[:encoding]=='lossless compact JSON'},brief_bytes:brief.bytesize,brief_sha256:sha(brief),index_sha256:sha(read(OUT+'/review-inputs.json')),source_freeze_sha256:sha(read(EXEC+'/source-freeze-v2.json')),builder_sha256:sha(read(__FILE__)),instructions_words:instructions.split.length,reviewer_invoked:false}
File.write(OUT+'/pack.json',JSON.pretty_generate(meta)+"\n");puts JSON.pretty_generate(meta)
