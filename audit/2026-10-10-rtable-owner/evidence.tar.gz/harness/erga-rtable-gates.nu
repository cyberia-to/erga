let runner = '/tmp/erga-rtable-execution-gate.nu'
for row in [
 ['workspace-check' 'stable' ['check' '--workspace' '--all-targets' '--locked' '--offline']],
 ['parent-workspace-check' 'parent' ['check' '--workspace' '--all-targets' '--locked' '--offline']],
 ['workspace-test' 'stable' ['test' '--workspace' '--locked' '--offline']],
 ['parent-workspace-test' 'parent' ['test' '--workspace' '--locked' '--offline']],
 ['workspace-release-build' 'bootstrap' ['build' '--release' '--locked' '--offline']],
 ['parent-workspace-release-build' 'parent-bootstrap' ['build' '--release' '--locked' '--offline']],
 ['workspace-clippy' 'stable' ['clippy' '--workspace' '--all-targets' '--locked' '--offline' '--' '-D' 'warnings']],
 ['parent-workspace-clippy' 'parent' ['clippy' '--workspace' '--all-targets' '--locked' '--offline' '--' '-D' 'warnings']],
 ['workspace-clippy-diagnostic' 'stable' ['clippy' '--workspace' '--all-targets' '--no-deps' '--locked' '--offline' '--' '-W' 'warnings']],
 ['parent-workspace-clippy-diagnostic' 'parent' ['clippy' '--workspace' '--all-targets' '--no-deps' '--locked' '--offline' '--' '-W' 'warnings']],
 ['workspace-fmt' 'stable' ['fmt' '--all' '--check']],
 ['parent-workspace-fmt' 'parent' ['fmt' '--all' '--check']],
 ['miner-check' 'stable' ['check' '-p' 'erga-miner' '--all-targets' '--locked' '--offline']],
 ['miner-tests' 'stable' ['test' '-p' 'autolykos' '-p' 'erga-miner' '--locked' '--offline']],
 ['cli-difftest' 'stable' ['run' '-p' 'erga-cli' '--bin' 'erga' '--locked' '--offline' '--' 'difftest']],
 ['semver-patch' 'semver' ['semver-checks' '-p' 'rtable-bench' '--release-type' 'patch' '--baseline-root' '/tmp/erga-rtable-owner-execution-v1/legacy/erga']]
] {
    ^nu $runner $row.0 $row.1 ($row.2 | to json --raw)
}
