require 'json'; require 'digest'; require 'fileutils'
r='/tmp/erga-rtable-owner-execution-v1'
sha=->(p){Digest::SHA256.file(p).hexdigest}
records=Dir["#{r}/logs/*.json"].sort.map{|p|JSON.parse(File.read(p))}
File.write("#{r}/commands.json",JSON.pretty_generate(records)+"\n")
envs=[]
packed=records.map do |c|
 env=c['environment']; index=envs.index(env) || begin envs << env;envs.length-1 end
 c.reject{|k,_|k=='environment'}.merge('environment_index'=>index)
end
File.write("#{r}/command-table.json",JSON.pretty_generate({environments:envs,records:packed,original_commands_sha256:sha.call("#{r}/commands.json"),rule:'Reconstruct each record by replacing environment_index with environments[index]; original command records remain in logs.'})+"\n")
paths=JSON.parse(File.read("#{r}/allowlist.json"))
normalize=->(data){data.gsub(%r{/private/tmp/erga-rtable-owner-execution-v1/(?:source|parent)},'<closure>').gsub(%r{/tmp/erga-rtable-owner-execution-v1/(?:source|parent)},'<closure>')}
sections={}
%w[parent-workspace-fmt workspace-fmt].each do |label|
 text=normalize.call(File.read("#{r}/logs/#{label}.stdout"))
 list=text.split(/(?=^Diff in )/).reject(&:empty?)
 unchanged=list.reject{|section|paths.any?{|p|section.start_with?("Diff in <closure>/erga/#{p}:")}}
 sections[label]=unchanged
 File.write("#{r}/#{label}-unchanged.txt",unchanged.join)
end
raise 'unchanged formatter mismatch' unless sections.values[0]==sections.values[1]
fmt={status:'unchanged formatter output equal after exact path normalization and exclusion only of source allowlist',sections:sections.transform_values(&:length),files:sections.keys.to_h{|k|[k,{path:"#{k}-unchanged.txt",sha256:sha.call("#{r}/#{k}-unchanged.txt")} ]},full_streams:sections.keys.to_h{|k|[k,sha.call("#{r}/logs/#{k}.stdout")]}}
File.write("#{r}/fmt-comparison.json",JSON.pretty_generate(fmt)+"\n")
# Keep actual complete diagnostics; summaries are not substitute streams.
diags={}
records.each do |c|
 next unless c['label'].include?('workspace')
 err=File.read("#{r}/logs/#{c['label']}.stderr")
 diags[c['label']]={exit_code:c['exit_code'],errors:err.lines.grep(/^error/).map(&:chomp),warnings:err.lines.grep(/^warning/).map(&:chomp),origins:err.lines.grep(/^\s*--> /).map(&:strip),raw_sha256:sha.call("#{r}/logs/#{c['label']}.stderr")}
end
File.write("#{r}/diagnostic-comparison.json",JSON.pretty_generate({disposition:'Parent RTable three E0133 + one E0596 discharged. Candidate exposes new mine private/missing field/API errors. Strict Clippy may stop at unchanged upstream lint debt; no claim of full unmasked diagnostics. Chime remains masked. No fixes outside scope.',gates:diags})+"\n")
