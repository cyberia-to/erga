# RTable and synchronous probe execution

Local candidate from Erga origin14b40d667b7fa927f62f46423cd8096f01cf704f,
Honeycrisp9cbd48070a136e24711896c930670fcff8a147fc,
Strata494df7a0973ae10a6cc1c2022e644d70449a29d6; no dirty sibling inputs.
Source10-path freeze-v2 SHA9985b42ba39fba4d78b43ba26c1b33147e71ce9d784f1feb255d6efee7451bde.
No manifest, lock, shader, provider or mine edits. Largest changed source242lines.
No commit/push/reviewer invoked by implementer. Root owns CODE review/decision/merge.

29 Cargo/rustfmt command records,58 complete raw streams:13 exit0,16 nonzero.
The exact executable/environment/arguments/start/end/exit/lock/stream hashes are
in logs; commands.json retains their complete records. command-table.json uses
lossless environment dictionaries; command-source-map.json pins each overlay.
Rustup1.95.0 rustc commit59807616/LLVM22.1.2, matching cargo/Clippy/rustfmt; actual
nightly-2025-11-26 compiler/rustdoc1.93nightly for error-code doctests. Jobs≤2.
No source edits after final freeze. Original PLAN/review inputs remain immutable.

Scoped debug and release each passed9 private tests,2 integration tests,10 stable
doctests. Final edition2021 formatted source debug rerun passed the same21 cases;
selected strict Clippy rerun passed. Check/alltargets and strictdocs passed.
Real nightly10 compile-fail witnesses cover E0277 Send/Sync, E0505 device lifetime,
E0616 private fields and E0502 live views across build/probe. Stable success alone
is not used to assert diagnostic codes. Final formatting-only source preserves
the tested mechanisms; no semantic production correction was necessary.

Native Apple M4 Max inputs: tables1,3,65,513; heights0/0x07060504; workers1/2/3;
reads0/1/2/63/64/65/257. All logical rows compare complete Blake2b256 bytes;56 literal
checksum cases and16 row literals came from independent offline Go x/crypto,
including a published BoringSSL eight-byte input. High-index row-function literals
exercise the existing hash reference, not enormous actual table allocations.
Repeated probe/build and new zero-filled table behavior are checked; one-read
built literals must be nonzero. Real poisoned backing verifies all actual bytes
initialized; padding canaries survive CPU build/GPU probe, including usizeMAX
worker argument on only3rows. Payload never uses Vec; thread control allocates.

Private injected worker panic and simulated spawn rejection after one started
worker verify joining and terminal access closure. Production completion helper's
status0/1/2/3/4/5/u64MAX × errorNone/Some matrix permits only completed+None.
These are simulated facts, not actual GPU fault or OS spawn-failure injections.
Native different-device rejection is source proof on this one-device host. Relative
Buffer-before-Block destruction follows declaration order, not destructor tracing.
No fake native owner/handle, legacy unsafe runtime or unsupported-platform run.

CLI verify4 preserves1048576 reads and returned matching c87de3f766ca8917 CPU/GPU
checksums. Invalid present exponent33 or text exits1 before allocation. CLI timing
is incidental output, not a performance claim. Direct autolykos/miner7 tests and
512-nonce production GPU/CPU difftest passed; miner does not depend on RTable,
so these are bounded repository diagnostics, not RTable reverse-closure evidence.

Parent/candidate workspace check/test/bootstraprelease/strict and warnings Clippy
all exit101. Parent reports threeE0133+oneE0596 in old RTable lib58/80/80/107. The
unit discharges those and now exposes eight mine-bench lib errors: n at257/307/444,
private buffer272/274/285 and block306/443. These are new API breaks, not unrelated
pre-existing faults. Other planned mine main/lifetime/mutability failures and old
chime errors remain masked. Actual strict and diagnostic Clippy stop at those same
compile errors; no complete downstream lint-clean claim. Both workspace fmt runs
exit1;154 unchanged sections are byte-identical after path normalization and
excluding only allowed changed files. Complete raw formatting output is retained.

Patch semver diagnostic against Erga tagv0.30.0/848e17e and historical Honey7b148906
exits100,9 major lint classes. That compile-only baseline uses the preceding
reviewed one-line lock normalization; current candidate and parent locks have no
delta. It is not a current-provider release closure and never executed old owners.
The tool reports removed functions/method/fields, private construction, new enum
variants, parameter count, mutable receivers and type lifetimes; its doc-hidden
finding denotes private fields, not an added doc(hidden) attribute.

Public API changes beyond tool coverage: RTable/Probe gain borrowed-device lifetime;
RTable raw block/buffer/n and IOSurface ID vanish; bytes/row_count replace metadata
and logical read access. build_parallel needs &mut and returns Result; cpu_checksum
returns Result. Probe::open borrows Gpu; run needs &mut Probe/&mut RTable, owns its
accumulator and returns Result<u64> rather than accepting a Buffer. Public raw read/
write/LCG helpers removed; structured worker/state/count error variants added.
Mine migration must add a reviewed exact actual-extent import path, not infer it
from logical slice length. No compatibility shim or public raw escape was added.

Known duplication: Erga bench-owner maintenance owns both private import_memory
copies until a separately scoped consolidation; no speculative roadmap row. Unused
acpu/blake2 direct dependencies remain frozen. No benchmark/default CLI, epoch
buildbench, mining/network/powermetrics or packaging gate ran. No full workspace,
phase/row6/Image/provider safety/physical-contiguity/pinning/rung/release claim.

Initial retained preparation failures: owned-fmt first used edition2024 and its
edition2021 check exited1; corrected only imports/assert wrapping, retained v1
bytes/manifest, repeated finalfmt/debug/Clippy. Artifact verifier first assumed
libc was the first unimem dependency in historical lock; it was after crossbeam-
queue. Corrected verifier matches exact original single-line deletion; no tested
source or lock changed and no gate rerun was needed. Source and receipt status
are independently verified rather than inferred from the summary.

## Commands

| label | command (exact executable/env in record) | exit |
|---|---|---:|
| focused-debug-01 | `cargo test -p rtable-bench --locked --offline` | 0 |
| selected-clippy | `cargo clippy -p rtable-bench --all-targets --no-deps --locked --offline -- -Dwarnings` | 0 |
| selected-check | `cargo check -p rtable-bench --all-targets --locked --offline` | 0 |
| strict-docs | `cargo doc -p rtable-bench --no-deps --locked --offline` | 0 |
| focused-release | `cargo test -p rtable-bench --release --locked --offline` | 0 |
| owned-fmt | `rustfmt --check --edition 2021 --config skip_children=true rs/rtable-bench/src/lib.rs rs/rtable-bench/src/main.rs rs/rtable-bench/src/table.rs rs/rtable-bench/src/probe.rs rs/rtable-bench/src/import_memory.rs rs/rtable-bench/src/table/tests.rs rs/rtable-bench/src/probe/tests.rs rs/rtable-bench/tests/owner.rs rs/rtable-bench/tests/support/vectors.rs` | 1 |
| nightly-borrow-docs | `cargo test -p rtable-bench --doc --locked --offline` | 0 |
| cli-verify | `cargo run -p rtable-bench --bin rtable-bench --locked --offline -- verify 4` | 0 |
| cli-invalid-high | `cargo run -p rtable-bench --bin rtable-bench --locked --offline -- verify 33` | 1 |
| cli-invalid-text | `cargo run -p rtable-bench --bin rtable-bench --locked --offline -- verify wat` | 1 |
| owned-fmt-final | `rustfmt --check --edition 2021 --config skip_children=true rs/rtable-bench/src/lib.rs rs/rtable-bench/src/main.rs rs/rtable-bench/src/table.rs rs/rtable-bench/src/probe.rs rs/rtable-bench/src/import_memory.rs rs/rtable-bench/src/table/tests.rs rs/rtable-bench/src/probe/tests.rs rs/rtable-bench/tests/owner.rs rs/rtable-bench/tests/support/vectors.rs` | 0 |
| focused-debug-final | `cargo test -p rtable-bench --locked --offline` | 0 |
| selected-clippy-final | `cargo clippy -p rtable-bench --all-targets --no-deps --locked --offline -- -Dwarnings` | 0 |
| workspace-check | `cargo check --workspace --all-targets --locked --offline` | 101 |
| parent-workspace-check | `cargo check --workspace --all-targets --locked --offline` | 101 |
| workspace-test | `cargo test --workspace --locked --offline` | 101 |
| parent-workspace-test | `cargo test --workspace --locked --offline` | 101 |
| workspace-release-build | `cargo build --release --locked --offline` | 101 |
| parent-workspace-release-build | `cargo build --release --locked --offline` | 101 |
| workspace-clippy | `cargo clippy --workspace --all-targets --locked --offline -- -D warnings` | 101 |
| parent-workspace-clippy | `cargo clippy --workspace --all-targets --locked --offline -- -D warnings` | 101 |
| workspace-clippy-diagnostic | `cargo clippy --workspace --all-targets --no-deps --locked --offline -- -W warnings` | 101 |
| parent-workspace-clippy-diagnostic | `cargo clippy --workspace --all-targets --no-deps --locked --offline -- -W warnings` | 101 |
| workspace-fmt | `cargo fmt --all --check` | 1 |
| parent-workspace-fmt | `cargo fmt --all --check` | 1 |
| miner-check | `cargo check -p erga-miner --all-targets --locked --offline` | 0 |
| miner-tests | `cargo test -p autolykos -p erga-miner --locked --offline` | 0 |
| cli-difftest | `cargo run -p erga-cli --bin erga --locked --offline -- difftest` | 0 |
| semver-patch | `cargo semver-checks -p rtable-bench --release-type patch --baseline-root /tmp/erga-rtable-owner-execution-v1/legacy/erga` | 100 |
