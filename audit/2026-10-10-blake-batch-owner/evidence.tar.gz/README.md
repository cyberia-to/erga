# Blake batch execution receipt

Source frozen2026-10-10 at Erga origin/main and latest tag v0.30.0
848e17e2522db2f6225ad72d9b1797f8735d26d0, with exactly8 explicit source/test/spec/lock
overlays in source-freeze.json SHA297e4959c0f4257c7b985ee9aeaa0194677e367a6e0e7ec0748bd187298d2d98.
Honeycrisp9cbd48070a136e24711896c930670fcff8a147fc and
Strata494df7a0973ae10a6cc1c2022e644d70449a29d6 are committed-origin archives. Four
new Rust files; every changed/new Rust file54–287 lines. No post-freeze edits.
This is a local reviewed candidate overlay, not a release or whole-Erga repair.
Original worktrees were not edited or used as build inputs.

PLAN APPROVE is retained verbatim in plan-review-approved.txt; its96-input brief
and manifests remain immutable under /tmp/erga-blake-batch-plan-v1. Implementation
adopts the optional status/drop-order evidence notes without changing scope.
The current physical-page requirement is unchanged; VM-region compatibility,
initialization and synchronization results do not settle physical/pinning policy.
Root owns the fresh different-vendor CODE review, decision label, final audit/commit/merge.

## Actual verification

The21 named command records below have42 complete raw streams:12 exit0 and9
nonzero. This includes one initial corrected scoped Clippy failure and both
parent/candidate fmt diagnostics; it is not a count of independent features.
Exact executable paths, argv, cwd, full environment, times, lock/source-overlay
hashes and stream hashes are in commands.json and logs/*.json. Actual toolchain
metadata is in toolchains.json: rustup1.95.0 commit59807616e1, LLVM22.1.2, matching
cargo/rustc/rustdoc/rustfmt/Clippy; nightly2025-11-26 is1.93.0-nightly80d8f292d8,
LLVM21.1.5. Native host Apple M4 Max, SDK26.4.1. Jobs2, private targets, no heavy
parallel closures. Targets observed about2.44GiB total after final command;
no benchmark, epoch buildbench, share/network/mining or powermetrics loop ran.

- Focused final debug and release each pass9 library tests +1 integration test
  +6 doctests. The3 existing reference tests are included; known_vector_abc is
  explicitly a preexisting false witness and is not independent vector evidence.
- New real native checks: all4 variants, counts1,2,3,4,63,64,65, two fills/reuses,
  full32-byte CPU/reference and separately published BoringSSL literal equality;
  poisoned real full extents zeroed by production initializer; both padding tails
  unchanged through all4 variant dispatches; inputs unchanged; invalid-width
  rejection preserves usable bytes/state. Setup failure is test failure, no skips.
- Actual nightly compiler+rustdoc checks all6 expected error-code doctests:
  E0499/E0502 borrow exclusion, E0505 factory lifetime, E0277 !Send and !Sync.
  Stable doctest success alone is not treated as matching error-code evidence.
- Scoped all-target Clippy, owned fmt, check and strict docs pass. First scoped
  Clippy flagged manual_is_multiple_of at lib106; replacing the remainder test
  by its exact is_multiple_of equivalent preserved overflow-safe ceil arithmetic.
  Initial raw receipt/overlay are retained; final debug/release reran afterwards.
- Existing Blake CLI verify passes4096 hashes for each of4 variants. Direct miner
  check and7 tests (5 Autolykos +2 miner) pass. Real CLI difftest passes512 nonces
  on Apple M4 Max. These bounded checks are not mining or product conformance.
- Remaining workspace check/test/bootstrap-release/strict-Clippy/warnings-Clippy
  stop at RTable3 E0133 +1 E0596, lib58/80/107. They are remaining failures induced
  by HoneyPR14's corrected raw-access boundary, newly exposed after this Blake
  owner migration, not unrelated preexisting lint debt. Mine owner failures and
  old chime overflow runtime failures remain masked; no claim they disappeared.
- Parent and candidate workspace fmt exit1. After excluding only changed
  lib/main sections and normalizing source roots, the160 unchanged sections are
  byte-identical84469 bytes (including LF), SHA
  a6379a4fa90bdf92e41cec6cf621a7a90ae0b93c4e973b5dedd9853996b2d532.
  New/changed owned Rust is separately rustfmt-clean. No unrelated formatting edit.
- Explicit patch semver diagnostic exits100:229 checks,223 pass,6 fail,31 skip.
  Baseline is latest Erga tag848e17e plus compile-only historical Honey7b148906
  and the same one-line lock normalization; it is labeled diagnostic, not the
  current-provider release closure. No legacy raw owner runtime was executed.

## API and evidence limits

Intentional incompatible changes: remove ZeroCopyBuf (including public fields,
constructor, native ID and unsafe-in-effect CPU getters); replace alloc_buffers
with lifetime-bound alloc_batch; dispatch takes one &mut Batch and width, no
caller count/pair, and returns Result; fill_inputs takes &mut Batch and seed and
returns Result; verify_zero_copy takes &Batch and returns Result<usize,GpuError>.
GpuBlake2b fields gpu/variant/max_threads_per_group/thread_execution_width become
private; read-only metadata getters replace the latter three, no device accessor.
Batch views expose only fixed logical records; factory lifetime and inherited
!Send/!Sync are part of the new surface. No compatibility shim or version bump.
Semver's6 lint classes capture removed struct/method/fields and parameter counts;
its doc_hidden finding describes the newly private fields, not an added source
#[doc(hidden)] attribute. Type/Result/lifetime changes also require the explicit
catalog above; the tool is not exhaustive.

Failed native completion is covered by the actual private completion function's
simulated status/error matrix plus source review, not an injected real GPU fault.
A real different-device rejection was unavailable on this single-device host;
its identity guard is source-reviewed, not measured. Buffer-before-Block relative
drop order follows private field declaration and Rust's drop rule; source evidence,
not native destructor tracing. No fake handles or invalid Block were constructed.
No generic Buffer/provider soundness, RTable/mine ownership, Kadek row6, ring1,
physical contiguity/pinning, performance or package/release closure claim.
Named packaging/bundle.nu and huge epoch buildbench were not run; both stay explicit
unexecuted limits. No measured performance table changed. Initialization now zeros
both actual backings and dispatch performs checks; old timings are not comparable.

Lock delta is exactly deletion of normal dependency libc from unimem0.2.0; no
version/checksum/manifest changes. The original locked metadata failure is retained
in PLAN receipts. /tmp/erga-blake-execution-verify.rb independently verifies all814
candidate committed paths plus4 new files, both diagnostic closures, all21 records/
42 streams, explicit lock delta, immutable PLAN inputs and source freeze.

## Commands

| label | exact command (executable path/environment in record) | exit |
|---|---|---:|
| focused-debug-1 | `cargo test -p blake-bench --locked --offline` | 0 |
| scoped-clippy-1 | `cargo clippy -p blake-bench --all-targets --no-deps --locked --offline -- -D warnings` | 101 |
| scoped-clippy-2 | `cargo clippy -p blake-bench --all-targets --no-deps --locked --offline -- -D warnings` | 0 |
| owned-fmt | `rustfmt --check --edition 2021 --config skip_children=true rs/blake-bench/src/lib.rs rs/blake-bench/src/main.rs rs/blake-bench/src/batch.rs rs/blake-bench/src/import_memory.rs rs/blake-bench/src/batch/tests.rs rs/blake-bench/tests/batch.rs` | 0 |
| focused-debug-final | `cargo test -p blake-bench --locked --offline` | 0 |
| nightly-borrow-docs | `cargo test -p blake-bench --doc --locked --offline` | 0 |
| focused-release | `cargo test -p blake-bench --release --locked --offline` | 0 |
| scoped-check | `cargo check -p blake-bench --all-targets --locked --offline` | 0 |
| strict-docs | `cargo doc -p blake-bench --no-deps --locked --offline` | 0 |
| cli-verify | `cargo run -p blake-bench --bin blake-bench --locked --offline -- verify` | 0 |
| workspace-check | `cargo check --workspace --all-targets --locked --offline` | 101 |
| workspace-test | `cargo test --workspace --locked --offline` | 101 |
| workspace-release-build | `cargo build --release --locked --offline` | 101 |
| miner-check | `cargo check -p erga-miner --all-targets --locked --offline` | 0 |
| miner-tests | `cargo test -p autolykos -p erga-miner --locked --offline` | 0 |
| cli-difftest | `cargo run -p erga-cli --bin erga --locked --offline -- difftest` | 0 |
| parent-fmt | `cargo fmt --all --check` | 1 |
| workspace-fmt | `cargo fmt --all --check` | 1 |
| workspace-clippy | `cargo clippy --workspace --all-targets --locked --offline -- -D warnings` | 101 |
| workspace-clippy-diagnostic | `cargo clippy --workspace --all-targets --no-deps --locked --offline -- -W warnings` | 101 |
| semver-patch | `cargo semver-checks -p blake-bench --release-type patch --baseline-root /tmp/erga-blake-batch-execution-v1/legacy/erga` | 100 |

Initial development-only diagnostics: the first artifact verifier compared binary
and UTF-8 strings incorrectly; corrected comparison then passed, no source or
receipt bytes changed. An attempted cosmetic CLI edit matched no comment and
failed before writing that file; the harmless original block is intentionally
retained. Tool metadata capture initially called Nu's builtin uname with -a;
corrected to external ^uname, then captured actual tool versions. These are harness
preparation errors, not additional candidate Cargo commands or suppressed gates.
