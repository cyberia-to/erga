def main [] {
    let root = '/tmp/erga-blake-batch-execution-v1'
    let owned = '/Users/master/cyber/erga-unimem-bench-owners'
    let paths = ['Cargo.lock', 'specs/README.md', 'rs/blake-bench/src/lib.rs', 'rs/blake-bench/src/main.rs', 'rs/blake-bench/src/batch.rs', 'rs/blake-bench/src/import_memory.rs', 'rs/blake-bench/src/batch/tests.rs', 'rs/blake-bench/tests/batch.rs']
    let rows = ($paths | each {|path| {path: $path, sha256: (open --raw ($owned | path join $path) | hash sha256)} })
    let body = ($rows | to json)
    let sha = ($body | hash sha256)
    let snapshot = ($root | path join overlays $sha)
    mkdir $snapshot
    for path in $paths {
        let out = ($root | path join source erga $path)
        mkdir ($out | path dirname)
        cp --force ($owned | path join $path) $out
        let saved = ($snapshot | path join $path)
        mkdir ($saved | path dirname)
        if not ($saved | path exists) { cp ($owned | path join $path) $saved }
    }
    if not ($snapshot | path join overlay.json | path exists) { $body | save ($snapshot | path join overlay.json) }
    $body | save --force ($root | path join overlay.json)
    print $sha
}
