require 'json';require 'digest';require 'open3';require 'time';require 'fileutils'
PLAN='/tmp/erga-blake-batch-plan-v1'; EXEC='/tmp/erga-blake-batch-execution-v1';OUT='/tmp/erga-blake-batch-code-v2';OWN='/Users/master/cyber/erga-unimem-bench-owners'
FileUtils.mkdir_p(OUT)
def sha(s)=Digest::SHA256.hexdigest(s)
def data(p)=File.binread(p)
def row(name,path,revision,**extra)
  body=data(path);packed=body;encoding='exact bytes'
  if path.end_with?('.json')
    packed=JSON.generate(JSON.parse(body)).b;encoding='lossless compact JSON; structural equality verified'
  end
  {name:name,path:path,revision:revision,sha256:sha(body),source_bytes:body.bytesize,packed_sha256:sha(packed),packed_bytes:packed.bytesize,encoding:encoding,content:packed}.merge(extra)
end
inputs=JSON.parse(data(PLAN+'/review-inputs.json')).map{|e|extra=e.slice('git_repo','git_path').transform_keys(&:to_sym);row(e['name'],e['path'],e['revision'],**extra)}
freeze=JSON.parse(data(EXEC+'/source-freeze.json'))
freeze['files'].each do |e|
  raise 'frozen source changed' unless sha(data(OWN+'/'+e['path']))==e['sha256']
  # Cargo.lock original+one-line diff already fully supplied, avoid a second121KB
  # identical body. All changed/new Rust and the compact contract are full bodies.
  next if e['path']=='Cargo.lock'
  inputs<<row('candidate/erga/'+e['path'],OWN+'/'+e['path'],'frozen candidate overlay on '+freeze['base'],frozen_sha256:e['sha256'])
end
%w[README.md plan-review-approved.txt source-freeze.json tracked-source.diff command-table.json review-deduplication.json verification.json fmt-comparison.json diagnostic-closures.json toolchains.json resource-observation.json].each{|p|inputs<<row('execution/'+p,EXEC+'/'+p,'actual frozen candidate receipts2026-10-10; source overlay identified per command')}
# All non-format raw streams, including first failure, are included. Full fmt
# streams are retained with hashes and independently verified equality of debt.
Dir[EXEC+'/logs/*.{stdout,stderr}'].sort.each do |p|
  next if %w[parent-fmt.stdout workspace-fmt.stdout].include?(File.basename(p))
  inputs<<row('execution/logs/'+File.basename(p),p,'complete actual command output, including failures; command metadata above')
end
['/tmp/erga-blake-execution-gate.nu','/tmp/erga-blake-overlay.nu','/tmp/erga-blake-diagnostic-closures.nu','/tmp/erga-blake-execution-verify.rb'].each{|p|inputs<<row('execution/harness/'+File.basename(p),p,'exact bounded gate/overlay/archive verifier source')}
raise 'duplicate names' unless inputs.map{|e|e[:name]}.uniq.length==inputs.length
instructions=<<~TEXT
Fresh independent CODE review. Return explicit APPROVE or REQUEST CHANGES with actual blockers separated from optional notes. Do not invoke tools: complete relevant original/candidate source bodies, complete raw non-format command output, losslessly dictionary-encoded command environments, exact frozen PLAN and approved verdict, pinned primary references, original diagnostics and independent execution verification follow. Candidate is one narrow Blake benchmark batch owner and sole CLI migration discovered from HoneyPR14/Kadek native Image foundation row6; it does not close Erga/RTable/mining, general provider safety, native Image or physical/pinning policy. Review canon/scope first, then Rust/native safety and behavior; independently inspect implementation, not merely trust PLAN approval or green scoped tests.

Erga origin848e17e (also latest tagv0.30.0), Honey9cbd4807, Strata494df7, all committed archives. Exactly8 source/test/spec/lock paths,4new Rust files; original and tested/owned final bytes verified. source-freeze.json identifies final overlay3a828fd...; first scoped lint was corrected before final debug/release. PLAN inputs and frozen production unchanged after source freeze. Original Erga Cargo.lock is included in full plus exact one-line removal in tracked-source.diff and freeze; its otherwise-identical candidate121KB body is intentionally not duplicated. Every changed/new Rust and contract body is included in full. Every nonzero owner/caller scan file and all35-file zero inventory are included, with existing unrelated large files explicitly unchanged. JSON sections are only losslessly compacted: original and packed SHA/length named, exact non-JSON source/test/primary bytes preserved. New-file diff duplication is removed only because every new file is already present in full; complete original diff remains hash-pinned. Command environment dictionaries reconstruct complete original records without loss. Full fmt raw streams remain in hashed execution artifacts; comparison verifies unchanged160sections byte-exact after path normalization and excluding only changed lib/main sections.

Inspect private Buffer-before-Block field drop order and every fallible construction path, full actual-extent initialization before references/import, logical vs padding bounds, checked count/page/isize/device allocation layout, current RW VM leaf and8-byteulong alignment proof with exact FFI ABI, retained private &Gpu lifetime and exact native-device identity before encoding. Imports never escape; views exclude dispatch via &mut Batch, !Send/!Sync inherited without unsafe impl. Existing Encoder::push copies4-byte count. Variant sealed with pipeline. Exact ceil uses division+remainder predicate without overflow and no whole-group surplus lane; dual-hash uint indexing remains bounded throughu32MAX. Do not infer bounds from practical memory size. Commands and encoder are retained until adjacent submit/wait finishes; no fallible/untrusted gap; status and native error checked after wait, terminal flag clears only completed+None. Failures before submit preserve state; failures after wait permanently deny views. Check CLI errors cannot become successful timing, and all benchmark loop/count/trial constants remain unchanged. No benchmarks or mining loops were run; construction zeroing/check costs are disclosed, no performance claim.

Actual scoped debug/release each10runtime+6doctests, real nightly6expected-code witnesses, scoped strictClippy/fmt/check/docs, Blake CLI4×4096, direct miner7tests/check and real512nonce GPU/CPU difftest passed. Published independent BoringSSL32-byte literal is embedded with license; comparisons use full bytes for all4variants and1,2,3,4,63,64,65, two fills/reuse; real poisoned initialization and private padding canaries, pre-submit preservation. Existing reference::known_vector_abc is explicitly not a valid witness. Native completion fault matrix is simulated through actual helper; true cross-device branch and relative native destructor order are source proof, not measured fault/drop tracing. No invalid handles or fake Block used.

21commands/42rawstreams:12zero/9nonzero, including initial correctedlint, oldfmt, six intentional semver lint classes and workspace failures. Workspace check/test/bootstraprelease/strict and warningsClippy now stop at RTable3E0133+1E0596 remaining from HoneyPR14 raw-contract repair; mine/chime stay masked, not fixed. Scope remains Blake only. Public API break catalog includes types/Result/lifetimes beyond semver tool. Named huge epoch buildbench and packaging remain explicitly unrun; no fullrepository/ring/release claim. Complete own source+selected dependent sources show exclusions. Root handles any source correction, fresh review, audit, decision label and commit/merge. Find actionable safety/lifecycle/correctness holes, invalid tests, regressions within scope or false evidence claims. Avoid requiring unrelated provider/RTable/miner/physical-policy fixes or cosmetic churn to this frozen unit.
TEXT
raise 'review instructions too long' if instructions.split.length>1500
brief=instructions.b+inputs.map{|e|"\n\n===== #{e[:name]} @ #{e[:revision]}, ORIGINAL-SHA256 #{e[:sha256]}, PACKED-SHA256 #{e[:packed_sha256]}, #{e[:encoding]} =====\n".b+e[:content]}.join
File.binwrite(OUT+'/brief.txt',brief)
index=inputs.map{|e|e.reject{|k,v|k==:content}}
File.write(OUT+'/review-inputs.json',JSON.pretty_generate(index)+"\n")
meta={created:Time.now.utc.iso8601,source_freeze_sha256:sha(data(EXEC+'/source-freeze.json')),inputs:inputs.length,committed_git_bodies:inputs.count{|e|e[:git_repo]},candidate_full_bodies:freeze['files'].length-1,compacted_json:inputs.count{|e|e[:encoding].start_with?('lossless')},brief_bytes:brief.bytesize,brief_sha256:sha(brief),review_inputs_sha256:sha(data(OUT+'/review-inputs.json')),builder_sha256:sha(data(__FILE__)),instructions_words:instructions.split.length,reviewer_invoked:false}
File.write(OUT+'/pack.json',JSON.pretty_generate(meta)+"\n")
puts JSON.pretty_generate(meta)
