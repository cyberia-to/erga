require 'json';require 'digest';require 'open3'
r='/tmp/erga-blake-batch-plan-v1'; repo='/Users/master/cyber/erga-unimem-bench-owners';pin='848e17e2522db2f6225ad72d9b1797f8735d26d0'
s,err,status=Open3.capture3('git','-C',repo,'ls-tree','-r','--name-only',pin);raise err unless status.success?
pattern=/ZeroCopyBuf|GpuBlake2b|fill_inputs|verify_zero_copy|RTable|Probe::|\.block|\.buffer|as_bytes_mut|as_bytes\(|\.wrap\(|iosurface_id|build_parallel|cpu_checksum|dispatch_with_bytes/
files=s.lines.map(&:strip).select{|p|p.end_with?('.rs')}.map do |p|
 body=File.read("#{r}/source/erga/#{p}")
 {path:p,sha256:Digest::SHA256.hexdigest(body),matches:body.lines.each_with_index.filter_map{|line,i|{line:i+1,text:line.chomp} if line.match?(pattern)}}
end
File.write("#{r}/caller-inventory.json",JSON.pretty_generate({revision:pin,command:'git ls-tree -r --name-only <pin>, every .rs byte-hashed and complete line scan',pattern:pattern.source,files:files})+"\n")
orig=File.read("#{r}/Cargo.lock.origin");diag=File.read("#{r}/source/erga/Cargo.lock")
expected=orig.sub(/(name = "unimem"\nversion = "0.2.0"\ndependencies = \[\n "crossbeam-queue",\n) "libc",\n/,'\1')
raise 'lock delta larger than one obsolete line' unless expected==diag
metadata=JSON.parse(File.read("#{r}/logs/metadata-diagnostic-lock.stdout"));locals=metadata['packages'].select{|p|p['source'].nil?}
raise 'metadata escaped' unless locals.all?{|p|File.realpath(p['manifest_path']).start_with?(File.realpath("#{r}/source")+'/')}
verified=JSON.parse(File.read("#{r}/origins.json")).map do |source|
 rows=JSON.parse(File.read("#{r}/#{source['name']}-source.json"))
 rows.each do |row|
  file="#{r}/source/#{source['name']}/#{row['path']}"
  want=(source['name']=='erga' && row['path']=='Cargo.lock') ? Digest::SHA256.hexdigest(diag) : row['sha256']
  raise "archive drift #{file}" unless Digest::SHA256.file(file).hexdigest==want
 end
 {name:source['name'],revision:source['revision'],files:rows.size}
end
logs=Dir["#{r}/logs/*.json"].map{|p|j=JSON.parse(File.read(p));%w[stdout stderr].each{|t|raise 'log drift' unless Digest::SHA256.file("#{r}/logs/#{j['label']}.#{t}").hexdigest==j["#{t}_sha256"]};j.slice('label','command','args','exit_code')}
File.write("#{r}/baseline-verification.json",JSON.pretty_generate({archives:verified,diagnostic_lock_only_delta:'remove obsolete libc dependency edge from unimem0.2.0 entry; other packages/checksums unchanged',origin_lock_sha256:Digest::SHA256.hexdigest(orig),diagnostic_lock_sha256:Digest::SHA256.hexdigest(diag),local_packages:locals.map{|p|p.slice('name','version','manifest_path')},records:logs,raw_source_methods_not_executed:true,all_rs_files:files.size})+"\n")
primary="#{r}/primary/blake2b256_tests.txt";body=File.read(primary)
vector=body.scan(/IN: ([0-9a-f]*)\nHASH: ([0-9a-f]+)/).find{|i,h|i.size==64}
File.write("#{r}/primary/vector.json",JSON.pretty_generate({repository:'BoringSSL',revision:'09f7078f953362d5c5afdd224118845327b60fb4',git_blob:Digest::SHA1.hexdigest("blob #{body.bytesize}\0"+body),url:'https://boringssl.googlesource.com/boringssl/+/09f7078f953362d5c5afdd224118845327b60fb4/src/crypto/blake2/blake2b256_tests.txt',download_command:"curl -fsSL '<url>?format=TEXT' -o blake2b256_tests.base64; base64 -D -i blake2b256_tests.base64 -o blake2b256_tests.txt",file_sha256:Digest::SHA256.hexdigest(body),input_hex:vector[0],expected_hex:vector[1],origin_description:'Published BoringSSL vectors generated with Go golang.org/x/crypto/blake2b.New256(nil), independent of Kadek/Erga/RustCrypto and GPU output.'})+"\n")
puts "#{files.size} Rust files; #{locals.size} local packages; #{logs.size} fresh bounded commands"
