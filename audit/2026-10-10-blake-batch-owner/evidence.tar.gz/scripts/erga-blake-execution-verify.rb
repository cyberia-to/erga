require 'json'; require 'digest'; require 'open3'; require 'time'
ROOT='/tmp/erga-blake-batch-execution-v1'; OWN='/Users/master/cyber/erga-unimem-bench-owners'; PLAN='/tmp/erga-blake-batch-plan-v1'
def read(p)=File.binread(p)
def sha(p)=Digest::SHA256.file(p).hexdigest
def git(repo,*args)
  o,e,s=Open3.capture3('git','-C',repo,*args); raise e unless s.success?;o.b
end
freeze=JSON.parse(read(ROOT+'/source-freeze.json')); overlay=JSON.parse(read(ROOT+'/overlay.json'));raise 'overlay manifest drift' unless sha(ROOT+'/overlay.json')==freeze['overlay_sha256']
raise 'HEAD drift' unless git(OWN,'rev-parse','HEAD').strip==freeze['base']
freeze['files'].each do |e|
  raise "owned drift #{e['path']}" unless sha(OWN+'/'+e['path'])==e['sha256'] && read(OWN+'/'+e['path'])==read(ROOT+'/source/erga/'+e['path'])
  raise 'source size drift' unless File.size(OWN+'/'+e['path'])==e['bytes']
  raise 'line budget' if e['path'].end_with?('.rs') && e['lines']>500
end
all_paths=0
JSON.parse(read(ROOT+'/origins.json')).each do |origin|
  rows=JSON.parse(read(ROOT+"/#{origin['name']}-source.json"));rows.each do |e|
    path=ROOT+"/source/#{origin['name']}/#{e['path']}"
    override=origin['name']=='erga' && overlay.find{|i|i['path']==e['path']}
    raise "archive drift #{path}" unless sha(path)==(override ? override['sha256'] : e['sha256'])
    raise 'manifest differs from committed origin' unless Digest::SHA256.hexdigest(git(origin['repo'],'show',"#{origin['revision']}:#{e['path']}"))==e['sha256']
    all_paths+=1
  end
end
original=git(OWN,'show',freeze['base']+':Cargo.lock')
expected=original.sub(/(name = "unimem"\nversion = "0.2.0"\ndependencies = \[\n "crossbeam-queue",\n) "libc",\n/,'\1')
raise 'wrong lock delta' unless original!=expected && expected==read(OWN+'/Cargo.lock')
records=Dir[ROOT+'/logs/*.json'].sort.map{|p|JSON.parse(read(p))}.sort_by{|r|r['start']}
records.each do |r|
  %w[stdout stderr].each{|stream|raise "gate stream #{r['label']} #{stream}" unless sha(ROOT+"/logs/#{r['label']}.#{stream}")==r[stream+'_sha256']}
  raise 'lock mutated' unless r['lock_before']==r['lock_after'] && r['lock_after']==Digest::SHA256.hexdigest(expected)
  if r['overlay_sha256']
    folder=ROOT+'/overlays/'+r['overlay_sha256'];raise 'overlay receipt missing' unless sha(folder+'/overlay.json')==r['overlay_sha256']
    JSON.parse(read(folder+'/overlay.json')).each{|e|raise 'overlay snapshot drift' unless sha(folder+'/'+e['path'])==e['sha256']}
  end
end
current=overlay.map{|e|e['path']}
normalized={}
%w[parent-fmt workspace-fmt].each do |label|
  raw=read(ROOT+"/logs/#{label}.stdout")
  blocks=raw.split(/(?=^Diff in )/).reject(&:empty?)
  kept=blocks.reject{|b|b.match?(%r{^Diff in /private/tmp/erga-blake-batch-execution-v1/(?:parent|source)/erga/(?:rs/blake-bench/src/(?:lib|main)\.rs):})}
  body=kept.join.gsub(%r{/private/tmp/erga-blake-batch-execution-v1/(?:parent|source)/},'<SOURCE>/')
  file=ROOT+"/#{label}-unmodified.txt";File.binwrite(file,body)
  normalized[label]={raw_sha256:Digest::SHA256.hexdigest(raw),raw_sections:blocks.length,omitted_changed_sections:blocks.length-kept.length,remaining_sections:kept.length,remaining_bytes:body.bytesize,remaining_sha256:sha(file)}
end
raise 'unmodified fmt debt differs' unless read(ROOT+'/parent-fmt-unmodified.txt')==read(ROOT+'/workspace-fmt-unmodified.txt')
File.write(ROOT+'/fmt-comparison.json',JSON.pretty_generate({comparison:'exact retained bytes after path normalization and removing only changed lib.rs/main.rs sections; final LF included',same_unmodified_debt:true,records:normalized})+"\n")
closures=JSON.parse(read(ROOT+'/diagnostic-closures.json'));closure_counts={}
%w[parent legacy].each do |kind|
  count=0; %w[erga honeycrisp strata].each do |name|
    origin=JSON.parse(read(ROOT+'/origins.json')).find{|e|e['name']==name}; pin=closures[kind][name]
    paths=git(origin['repo'],'ls-tree','-r','--name-only',pin).lines.map(&:chomp)
    paths.each do |path|
      actual=read(ROOT+"/#{kind}/#{name}/#{path}")
      wanted=(name=='erga' && path=='Cargo.lock') ? expected : git(origin['repo'],'show',"#{pin}:#{path}")
      raise "diagnostic closure drift #{kind}/#{name}/#{path}" unless actual==wanted
      count+=1
    end
  end
  closure_counts[kind]=count
end
summary=records.map{|r|r.slice('label','cwd','command','args','environment','start','end','exit_code','lock_before','lock_after','overlay_sha256','stdout_sha256','stderr_sha256')}
File.write(ROOT+'/commands.json',JSON.pretty_generate(summary)+"\n")
facts={checked:Time.now.utc.iso8601,source_base:freeze['base'],source_freeze_sha256:sha(ROOT+'/source-freeze.json'),unchanged_frozen_overlay:true,committed_candidate_archive_paths:all_paths,new_paths:overlay.count{|e|!JSON.parse(read(ROOT+'/erga-source.json')).any?{|o|o['path']==e['path']}},diagnostic_closure_paths:closure_counts,records:records.length,raw_streams:records.length*2,zero:records.count{|r|r['exit_code']==0},nonzero:records.count{|r|r['exit_code']!=0},fmt_unmodified_equal:true,explicit_one_line_lock_delta:true,plan_inputs_preserved:true}
# Every PLAN input remains byte-identical; sources in its compile scratch were not reused.
raise 'PLAN brief drift' unless sha(PLAN+'/brief.txt')==freeze['reviewed_plan_sha256']
JSON.parse(read(PLAN+'/review-inputs.json')).each{|e|raise "PLAN input drift #{e['path']}" unless sha(e['path'])==e['sha256']}
File.write(ROOT+'/verification.json',JSON.pretty_generate(facts)+"\n")
puts JSON.pretty_generate(facts)
