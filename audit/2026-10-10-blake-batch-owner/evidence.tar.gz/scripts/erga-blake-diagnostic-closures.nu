def main [] {
    let root = '/tmp/erga-blake-batch-execution-v1'
    let plan = '/tmp/erga-blake-batch-plan-v1'
    for kind in ['parent', 'legacy'] {
        for name in ['erga', 'honeycrisp', 'strata'] {
            let out = ($root | path join $kind $name)
            mkdir $out
            let archive = if $kind == 'legacy' and $name == 'honeycrisp' {
                let path = ($root | path join legacy-honeycrisp.tar)
                git -C /Users/master/cyber/honeycrisp-kadek-block-access archive --format=tar --output $path 7b148906263da5ea8aabc5ddb0e2e44ff2288ecc
                $path
            } else { $plan | path join ($name + '.tar') }
            tar -xf $archive -C $out
        }
        # Explicit identical diagnostic delta only, never old raw runtime.
        cp --force ($root | path join source erga Cargo.lock) ($root | path join $kind erga Cargo.lock)
    }
    {parent: {erga:'848e17e2522db2f6225ad72d9b1797f8735d26d0', honeycrisp:'9cbd48070a136e24711896c930670fcff8a147fc', strata:'494df7a0973ae10a6cc1c2022e644d70449a29d6', purpose:'fmt only, no old raw execution'}, legacy: {erga:'848e17e2522db2f6225ad72d9b1797f8735d26d0', honeycrisp:'7b148906263da5ea8aabc5ddb0e2e44ff2288ecc', strata:'494df7a0973ae10a6cc1c2022e644d70449a29d6', purpose:'compile-only semver diagnostics; not current-provider closure'}, both_lock: (open --raw ($root | path join source erga Cargo.lock) | hash sha256), old_provider_archive_sha256: (open --raw ($root | path join legacy-honeycrisp.tar) | hash sha256)} | to json | save ($root | path join diagnostic-closures.json)
}
