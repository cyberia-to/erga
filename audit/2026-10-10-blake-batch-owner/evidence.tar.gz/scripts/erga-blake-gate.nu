def main [label: string, mode: string, arguments_json: string] {
    let args = ($arguments_json | from json)
    let root = '/tmp/erga-blake-batch-plan-v1'
    let cwd = ($root | path join source erga)
    let toolchain = if $mode == 'nightly' { '/Users/master/.rustup/toolchains/nightly-2025-11-26-aarch64-apple-darwin/bin' } else { '/Users/master/.rustup/toolchains/1.95.0-aarch64-apple-darwin/bin' }
    let toolname = if $mode == 'rustfmt' { 'rustfmt' } else { 'cargo' }
    let gate_env = {
        PATH: ([$toolchain] | append $env.PATH),
        RUSTUP_TOOLCHAIN: (if $mode == 'nightly' { 'nightly-2025-11-26' } else { '1.95.0' }),
        RUSTUP_AUTO_INSTALL: '0', RUSTC: ($toolchain | path join rustc), RUSTDOC: ($toolchain | path join rustdoc),
        CARGO_TARGET_DIR: ($root | path join (if $mode == 'nightly' { 'target-nightly' } else { 'target-candidate' })),
        CARGO_BUILD_JOBS: '2', CARGO_INCREMENTAL: '0'
    }
    let gate_env = if $mode == 'docs' { $gate_env | insert RUSTDOCFLAGS '-Dwarnings' } else { $gate_env }
    let receipt = ($root | path join logs $"($label).json")
    if ($receipt | path exists) { error make {msg: 'refuse duplicate receipt'} }
    cd $cwd
    let lock_before = (open --raw Cargo.lock | hash sha256)
    let start = (date now)
    let result = (with-env $gate_env { run-external ($toolchain | path join $toolname) ...$args | complete })
    $result.stdout | save ($root | path join logs $"($label).stdout")
    $result.stderr | save ($root | path join logs $"($label).stderr")
    {label: $label, cwd: $cwd, command: ($toolchain | path join $toolname), args: $args, environment: $gate_env, start: ($start | format date '%+'), end: (date now | format date '%+'), exit_code: $result.exit_code, lock_before: $lock_before, lock_after: (open --raw Cargo.lock | hash sha256), origin_records_sha256: (open --raw ($root | path join origins.json) | hash sha256), stdout_sha256: ($result.stdout | hash sha256), stderr_sha256: ($result.stderr | hash sha256)} | to json | save $receipt
    print $"($label): exit ($result.exit_code)"
}
