require 'json';require 'digest';require 'open3';require 'time'
ROOT=ARGV.fetch(0,'/tmp/erga-blake-batch-code-v2');EXEC='/tmp/erga-blake-batch-execution-v1'
def read(p)=File.binread(p)
def hash(s)=Digest::SHA256.hexdigest(s)
meta=JSON.parse(read(ROOT+'/pack.json'));rows=JSON.parse(read(ROOT+'/review-inputs.json'));brief=read(ROOT+'/brief.txt')
raise 'pack drift' unless hash(brief)==meta['brief_sha256'] && brief.bytesize==meta['brief_bytes'] && hash(read(ROOT+'/review-inputs.json'))==meta['review_inputs_sha256']
sections=brief.split("\n\n===== ");sections.shift;raise 'count' unless sections.length==rows.length
git_count=0;compacted=0;frozen=0
rows.zip(sections).each do |row,section|
  h="#{row['name']} @ #{row['revision']}, ORIGINAL-SHA256 #{row['sha256']}, PACKED-SHA256 #{row['packed_sha256']}, #{row['encoding']} =====\n".b
  raise 'header' unless section.start_with?(h)
  body=section.byteslice(h.bytesize..);source=read(row['path'])
  raise "source SHA drift #{row['name']}" unless hash(source)==row['sha256'] && source.bytesize==row['source_bytes']
  raise 'packed SHA drift' unless hash(body)==row['packed_sha256'] && body.bytesize==row['packed_bytes']
  if row['encoding'].start_with?('lossless')
    raise 'JSON change' unless JSON.parse(source)==JSON.parse(body)
    compacted+=1
  else
    raise 'nonJSON bytes changed' unless body==source
  end
  if row['git_repo']
    content,err,status=Open3.capture3('git','-C',row['git_repo'],'show',"#{row['revision']}:#{row['git_path']}")
    raise "Git #{row['name']}" unless status.success? && content.b==source
    git_count+=1
  end
  if row['frozen_sha256']
    raise 'frozen source differs' unless row['frozen_sha256']==hash(source)
    frozen+=1
  end
end
raise 'source freeze drift' unless hash(read(EXEC+'/source-freeze.json'))==meta['source_freeze_sha256']
table=JSON.parse(read(EXEC+'/command-table.json'));original=JSON.parse(read(EXEC+'/commands.json'))
restored=table['records'].map{|r|r.reject{|k,_|k=='environment_sha256'}.merge('environment'=>table['environments'].fetch(r['environment_sha256']))}
raise 'command loss' unless restored==original && hash(read(EXEC+'/commands.json'))==table['original_sha256']
vector=JSON.parse(read('/tmp/erga-blake-batch-plan-v1/primary/vector.json'));test=read('/Users/master/cyber/erga-unimem-bench-owners/rs/blake-bench/tests/batch.rs');literal=test.match(/const PUBLISHED: \[u8; 32\] = \[(.*?)\];/m)[1].scan(/0x([[:xdigit:]]{2})/).flatten.join
raise 'independent literal mismatch' unless literal==vector['expected_hex']
tracked,err,status=Open3.capture3('git','-C','/Users/master/cyber/erga-unimem-bench-owners','diff','--','Cargo.lock','specs/README.md','rs/blake-bench/src/lib.rs','rs/blake-bench/src/main.rs')
raise 'tracked difference changed' unless status.success? && tracked.b==read(EXEC+'/tracked-source.diff')
o,e,s=Open3.capture3('git','-C','/Users/master/cyber/erga-unimem-bench-owners','diff','--check');raise e unless s.success?
facts={checked:Time.now.utc.iso8601,inputs:rows.length,sections:sections.length,git_bodies:git_count,full_candidate_bodies:frozen,compacted_json:compacted,nonjson_exact:true,all_command_records_losslessly_reconstructed:restored.length,published_literal_exact:true,tracked_difference_exact:true,diff_check_exit:0,brief_bytes:brief.bytesize,brief_sha256:hash(brief),reviewer_invoked:false}
File.write(ROOT+'/verification.json',JSON.pretty_generate(facts)+"\n")
all=rows.map{|r|r['path']}+%w[brief.txt review-inputs.json pack.json verification.json].map{|p|ROOT+'/'+p}+['/tmp/erga-blake-code-pack-v2.rb','/tmp/erga-blake-code-verify.rb']
File.write(ROOT+'/SHA256SUMS',all.uniq.map{|p|"#{hash(read(p))}  #{p}\n"}.join)
puts JSON.pretty_generate(facts)
