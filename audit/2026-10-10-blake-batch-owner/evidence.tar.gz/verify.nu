def main [root: path = '.'] {
    let root = ($root | path expand)
    let inventory = (open ($root | path join inventory.json))
    for row in $inventory {
        let path = ($root | path join $row.path)
        if not ($path | path exists) or (open --raw $path | hash sha256) != $row.sha256 { error make {msg: $"payload differs: ($row.path)"} }
    }
    let freeze = (open ($root | path join source-freeze.json))
    for row in $freeze.files {
        if (open --raw ($root | path join source $row.path) | hash sha256) != $row.sha256 { error make {msg: 'frozen source differs'} }
    }
    let records = (open ($root | path join commands.json))
    let current_lock = (open --raw ($root | path join source Cargo.lock) | hash sha256)
    for r in $records {
        for stream in ['stdout','stderr'] {
            if (open --raw ($root | path join logs $"($r.label).($stream)") | hash sha256) != ($r | get $"($stream)_sha256") { error make {msg: 'raw stream differs'} }
        }
        if $r.lock_before != $r.lock_after or $r.lock_after != $current_lock { error make {msg:'candidate lock changed'} }
        if $r.overlay_sha256 != null {
            let folder = ($root | path join overlays $r.overlay_sha256)
            if (open --raw ($folder | path join overlay.json) | hash sha256) != $r.overlay_sha256 { error make {msg:'overlay manifest changed'} }
            for item in (open ($folder | path join overlay.json)) {
                if (open --raw ($folder | path join $item.path) | hash sha256) != $item.sha256 { error make {msg:'tested overlay changed'} }
            }
        }
    }
    let table = (open ($root | path join command-table.json))
    let restored = ($table.records | each {|r| $r | reject environment_sha256 | insert environment ($table.environments | get $r.environment_sha256) })
    if $restored != $records { error make {msg:'command dictionary lost data'} }
    let original_lock = (open --raw ($root | path join plan Cargo.lock.origin) | hash sha256)
    for path in (glob ($root | path join plan logs '*.json')) {
        let r = (open $path)
        for stream in ['stdout','stderr'] {
            if (open --raw ($root | path join plan logs $"($r.label).($stream)") | hash sha256) != ($r | get $"($stream)_sha256") { error make {msg:'PLAN stream differs'} }
        }
        let expected = if $r.label == 'metadata-origin' { $original_lock } else { $current_lock }
        if $r.lock_before != $expected or $r.lock_after != $expected { error make {msg:'PLAN lock evidence differs'} }
    }
    let code = (open ($root | path join review pack.json))
    if (open --raw ($root | path join source-freeze.json) | hash sha256) != $code.source_freeze_sha256 { error make {msg:'reviewed source freeze differs'} }
    {payloads:($inventory | length), records:($records | length), raw_streams:(2 * ($records | length)), frozen_paths:($freeze.files | length), zero:($records | where exit_code == 0 | length), nonzero:($records | where exit_code != 0 | length), command_dictionary_lossless:true, all_payload_hashes_match:true, reran_native_work:false} | to json | print
}
